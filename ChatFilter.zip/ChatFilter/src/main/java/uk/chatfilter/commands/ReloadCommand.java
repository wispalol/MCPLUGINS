package uk.chatfilter.commands;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import uk.chatfilter.ChatFilterPlugin;

public class ReloadCommand implements CommandExecutor {
    private final ChatFilterPlugin plugin;

    public ReloadCommand(ChatFilterPlugin plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        plugin.reloadConfig();
        plugin.getFilterManager().reload();
        sender.sendMessage("ChatFilter reloaded.");
        return true;
    }
}
