package uk.chatfilter;
import org.bukkit.ChatColor;
import org.bukkit.entity.Player;
import java.util.List;

public class FilterManager {
    private final ChatFilterPlugin plugin;
    private List<String> blockedWords;
    private String mode;

    public FilterManager(ChatFilterPlugin plugin) {
        this.plugin = plugin;
        reload();
    }

    public void reload() {
        blockedWords = plugin.getConfig().getStringList("blocked-words");
        mode = plugin.getConfig().getString("filter-mode", "CENSOR").toUpperCase();
    }

    public String processMessage(Player player, String message) {
        if (player.hasPermission("chatfilter.bypass")) return message;
        String filtered = message;
        for (String word : blockedWords) {
            if (filtered.toLowerCase().contains(word.toLowerCase())) {
                if (mode.equals("BLOCK")) return null;
                if (mode.equals("CENSOR"))
                    filtered = filtered.replaceAll("(?i)" + word, "*".repeat(word.length()));
            }
        }
        return filtered;
    }
}
