package uk.chatfilter;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.AsyncPlayerChatEvent;

public class ChatListener implements Listener {
    private final FilterManager filterManager;

    public ChatListener(FilterManager filterManager) {
        this.filterManager = filterManager;
    }

    @EventHandler
    public void onChat(AsyncPlayerChatEvent event) {
        String result = filterManager.processMessage(event.getPlayer(), event.getMessage());
        if (result == null) event.setCancelled(true);
        else event.setMessage(result);
    }
}
