package uk.chatfilter;
import org.bukkit.plugin.java.JavaPlugin;
import uk.chatfilter.commands.ReloadCommand;

public class ChatFilterPlugin extends JavaPlugin {
    private FilterManager filterManager;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        filterManager = new FilterManager(this);
        getServer().getPluginManager().registerEvents(new ChatListener(filterManager), this);
        getCommand("chatfilter").setExecutor(new ReloadCommand(this));
    }

    public FilterManager getFilterManager() {
        return filterManager;
    }
}
