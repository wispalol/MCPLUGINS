# ChatFilter
A chat filter plugin for Minecraft 1.21.1.
