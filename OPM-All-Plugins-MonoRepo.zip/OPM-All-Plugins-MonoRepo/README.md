# OPM All Plugins (MonoRepo)

This repo contains all your Paper plugins in one place and can build **all JARs with one command**.

## Build all plugins (one command)
```bash
mvn -DskipTests clean package
```

## Where the JARs end up
Each plugin builds to its own:
`modules/<PluginName>/target/*.jar`

## GitHub Releases (one download → drop into /plugins)
This repo includes a GitHub Actions workflow that:
- Builds all plugins
- Collects all built JARs
- Publishes a Release asset zip: `OPM-All-Plugins-<tag>.zip`

### How to publish a release
Create and push a tag like:
```bash
git tag v1.0.0
git push origin v1.0.0
```

Then go to **Releases** and download the zip. Players can:
- Download the zip
- Extract
- Drop the `.jar` files into `plugins/`
- Restart server

## Requirements (local build)
- Java 21
- Maven
