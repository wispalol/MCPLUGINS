package uk.opm.mute.data;

import java.util.UUID;

public final class MuteEntry {
    public final UUID uuid;
    public final String name;
    public final long untilEpochMs; // -1 for permanent
    public final String reason;

    public MuteEntry(UUID uuid, String name, long untilEpochMs, String reason) {
        this.uuid = uuid;
        this.name = name;
        this.untilEpochMs = untilEpochMs;
        this.reason = reason;
    }

    public boolean isPermanent() {
        return untilEpochMs < 0;
    }

    public boolean isExpired() {
        return !isPermanent() && System.currentTimeMillis() > untilEpochMs;
    }

    public long timeLeftSeconds() {
        if (isPermanent()) return Long.MAX_VALUE;
        long diff = untilEpochMs - System.currentTimeMillis();
        return Math.max(0, diff / 1000L);
    }
}
