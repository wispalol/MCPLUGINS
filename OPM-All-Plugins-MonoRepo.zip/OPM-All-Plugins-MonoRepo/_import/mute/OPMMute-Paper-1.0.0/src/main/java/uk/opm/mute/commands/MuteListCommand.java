package uk.opm.mute.commands;

import net.kyori.adventure.text.Component;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import uk.opm.mute.OPMMutePlugin;
import uk.opm.mute.data.MuteEntry;
import uk.opm.mute.util.Msg;

import java.util.List;

public final class MuteListCommand implements CommandExecutor {

    private final OPMMutePlugin plugin;

    public MuteListCommand(OPMMutePlugin plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!sender.hasPermission("opmmute.list")) {
            sender.sendMessage(Component.text(Msg.color(plugin.getConfig().getString("messages.no-permission", "&cNo permission."))));
            return true;
        }

        List<MuteEntry> list = plugin.store().listActive();
        String header = Msg.color(plugin.getConfig().getString("messages.list-header", "&eMuted players ({count}):"))
                .replace("{count}", String.valueOf(list.size()));
        sender.sendMessage(Component.text(header));

        for (MuteEntry e : list) {
            String timeLeft = e.isPermanent() ? "permanent" : Msg.formatDuration(e.timeLeftSeconds());
            String reason = (e.reason == null || e.reason.isBlank()) ? "No reason" : e.reason;

            String line = Msg.color(plugin.getConfig().getString("messages.list-line", "&7- {player}: {timeLeft} (Reason: {reason})"))
                    .replace("{player}", e.name)
                    .replace("{timeLeft}", timeLeft)
                    .replace("{reason}", reason);
            sender.sendMessage(Component.text(line));
        }

        return true;
    }
}
