package uk.opm.mute;

import org.bukkit.plugin.java.JavaPlugin;
import uk.opm.mute.commands.MuteCommand;
import uk.opm.mute.commands.MuteListCommand;
import uk.opm.mute.commands.UnmuteCommand;
import uk.opm.mute.data.MuteStore;

public final class OPMMutePlugin extends JavaPlugin {

    private MuteStore store;

    @Override
    public void onEnable() {
        saveDefaultConfig();

        store = new MuteStore(this);
        store.load();

        getServer().getPluginManager().registerEvents(new ChatListener(this), this);

        if (getCommand("mute") != null) getCommand("mute").setExecutor(new MuteCommand(this));
        if (getCommand("unmute") != null) getCommand("unmute").setExecutor(new UnmuteCommand(this));
        if (getCommand("mutelist") != null) getCommand("mutelist").setExecutor(new MuteListCommand(this));
    }

    @Override
    public void onDisable() {
        if (store != null) store.save();
    }

    public MuteStore store() {
        return store;
    }
}
