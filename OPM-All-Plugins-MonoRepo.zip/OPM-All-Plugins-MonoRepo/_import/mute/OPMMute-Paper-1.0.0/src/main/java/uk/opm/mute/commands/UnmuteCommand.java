package uk.opm.mute.commands;

import net.kyori.adventure.text.Component;
import org.bukkit.OfflinePlayer;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import uk.opm.mute.OPMMutePlugin;
import uk.opm.mute.util.Msg;

import java.util.UUID;

public final class UnmuteCommand implements CommandExecutor {

    private final OPMMutePlugin plugin;

    public UnmuteCommand(OPMMutePlugin plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!sender.hasPermission("opmmute.unmute")) {
            sender.sendMessage(Component.text(Msg.color(plugin.getConfig().getString("messages.no-permission", "&cNo permission."))));
            return true;
        }

        if (args.length < 1) {
            sender.sendMessage(Component.text("§cUsage: /unmute <player>"));
            return true;
        }

        String targetName = args[0];
        Player online = plugin.getServer().getPlayerExact(targetName);
        UUID uuid;

        if (online != null) {
            uuid = online.getUniqueId();
        } else {
            OfflinePlayer off = plugin.store().findOfflineByName(targetName);
            if (off == null || off.getUniqueId() == null) {
                sender.sendMessage(Component.text("§cPlayer not found."));
                return true;
            }
            uuid = off.getUniqueId();
        }

        boolean removed = plugin.store().removeMute(uuid);
        if (!removed) {
            sender.sendMessage(Component.text(Msg.color(plugin.getConfig().getString("messages.not-muted", "&cThat player is not muted."))));
            return true;
        }

        String msg = Msg.color(plugin.getConfig().getString("messages.unmuted-by", "&aUnmuted {player}."))
                .replace("{player}", targetName);
        sender.sendMessage(Component.text(msg));

        if (online != null) online.sendMessage(Component.text("§aYou have been unmuted."));
        return true;
    }
}
