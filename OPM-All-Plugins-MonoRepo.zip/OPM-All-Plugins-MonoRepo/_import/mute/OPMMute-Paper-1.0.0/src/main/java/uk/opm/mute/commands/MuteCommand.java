package uk.opm.mute.commands;

import net.kyori.adventure.text.Component;
import org.bukkit.OfflinePlayer;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import uk.opm.mute.OPMMutePlugin;
import uk.opm.mute.data.MuteEntry;
import uk.opm.mute.util.DurationParser;
import uk.opm.mute.util.Msg;

import java.util.UUID;

public final class MuteCommand implements CommandExecutor {

    private final OPMMutePlugin plugin;

    public MuteCommand(OPMMutePlugin plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!sender.hasPermission("opmmute.mute")) {
            sender.sendMessage(Component.text(Msg.color(plugin.getConfig().getString("messages.no-permission", "&cNo permission."))));
            return true;
        }

        if (args.length < 2) {
            sender.sendMessage(Component.text("§cUsage: /mute <player> <duration> [reason]"));
            return true;
        }

        String targetName = args[0];
        DurationParser.Result dur = DurationParser.parse(args[1]);
        if (!dur.valid) {
            sender.sendMessage(Component.text(Msg.color(plugin.getConfig().getString("messages.bad-duration", "&cBad duration."))));
            return true;
        }

        String reason = "No reason";
        if (args.length >= 3) {
            StringBuilder sb = new StringBuilder();
            for (int i = 2; i < args.length; i++) {
                if (i > 2) sb.append(' ');
                sb.append(args[i]);
            }
            reason = sb.toString();
        }

        Player online = plugin.getServer().getPlayerExact(targetName);
        UUID uuid;
        String nameOut;

        if (online != null) {
            uuid = online.getUniqueId();
            nameOut = online.getName();
        } else {
            OfflinePlayer off = plugin.store().findOfflineByName(targetName);
            if (off == null || off.getUniqueId() == null) {
                sender.sendMessage(Component.text("§cPlayer not found."));
                return true;
            }
            uuid = off.getUniqueId();
            nameOut = off.getName() == null ? targetName : off.getName();
        }

        long until = dur.permanent ? -1 : (System.currentTimeMillis() + (dur.seconds * 1000L));
        plugin.store().setMute(new MuteEntry(uuid, nameOut, until, reason));

        String timeText = dur.permanent ? "permanent" : Msg.formatDuration(dur.seconds);
        String msg = Msg.color(plugin.getConfig().getString("messages.muted-by", "&aMuted {player} for {time}. Reason: {reason}"))
                .replace("{player}", nameOut).replace("{time}", timeText).replace("{reason}", reason);
        sender.sendMessage(Component.text(msg));

        if (online != null) {
            String key = dur.permanent ? "messages.muted-permanent" : "messages.muted";
            String tmsg = Msg.color(plugin.getConfig().getString(key, "&cYou are muted."))
                    .replace("{time}", timeText).replace("{reason}", reason);
            online.sendMessage(Component.text(tmsg));
        }

        return true;
    }
}
