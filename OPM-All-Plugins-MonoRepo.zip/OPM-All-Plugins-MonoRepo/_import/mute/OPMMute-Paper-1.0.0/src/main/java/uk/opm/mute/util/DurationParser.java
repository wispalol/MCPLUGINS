package uk.opm.mute.util;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public final class DurationParser {
    private DurationParser() {}

    private static final Pattern P = Pattern.compile("^(\\d+)([smhd])$", Pattern.CASE_INSENSITIVE);

    public static final class Result {
        public final boolean valid;
        public final boolean permanent;
        public final long seconds;

        private Result(boolean valid, boolean permanent, long seconds) {
            this.valid = valid;
            this.permanent = permanent;
            this.seconds = seconds;
        }
    }

    public static Result parse(String input) {
        if (input == null) return new Result(false, false, 0);
        String s = input.trim().toLowerCase();

        if (s.equals("perm") || s.equals("permanent") || s.equals("forever")) {
            return new Result(true, true, Long.MAX_VALUE);
        }

        Matcher m = P.matcher(s);
        if (!m.matches()) return new Result(false, false, 0);

        long n;
        try {
            n = Long.parseLong(m.group(1));
        } catch (NumberFormatException e) {
            return new Result(false, false, 0);
        }

        char unit = m.group(2).toLowerCase().charAt(0);
        long seconds = switch (unit) {
            case 's' -> n;
            case 'm' -> n * 60L;
            case 'h' -> n * 3600L;
            case 'd' -> n * 86400L;
            default -> 0L;
        };

        if (seconds <= 0) return new Result(false, false, 0);
        return new Result(true, false, seconds);
    }
}
