package uk.opm.mute.data;

import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.File;
import java.io.IOException;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

public final class MuteStore {
    private final JavaPlugin plugin;
    private final File file;
    private final Map<UUID, MuteEntry> mutes = new ConcurrentHashMap<>();

    public MuteStore(JavaPlugin plugin) {
        this.plugin = plugin;
        this.file = new File(plugin.getDataFolder(), "mutes.yml");
    }

    public MuteEntry getMute(UUID uuid) {
        MuteEntry e = mutes.get(uuid);
        if (e == null) return null;
        if (e.isExpired()) {
            mutes.remove(uuid);
            return null;
        }
        return e;
    }

    public void setMute(MuteEntry entry) {
        mutes.put(entry.uuid, entry);
        save();
    }

    public boolean removeMute(UUID uuid) {
        MuteEntry removed = mutes.remove(uuid);
        if (removed != null) save();
        return removed != null;
    }

    public List<MuteEntry> listActive() {
        List<MuteEntry> out = new ArrayList<>();
        for (MuteEntry e : mutes.values()) {
            if (!e.isExpired()) out.add(e);
        }
        out.sort(Comparator.comparing(a -> a.name.toLowerCase()));
        return out;
    }

    public void load() {
        if (!file.exists()) return;
        YamlConfiguration y = YamlConfiguration.loadConfiguration(file);

        for (String key : y.getKeys(false)) {
            try {
                UUID uuid = UUID.fromString(key);
                String name = y.getString(key + ".name", "Unknown");
                long until = y.getLong(key + ".until", -1);
                String reason = y.getString(key + ".reason", "No reason");
                mutes.put(uuid, new MuteEntry(uuid, name, until, reason));
            } catch (Exception ignored) {}
        }
    }

    public void save() {
        YamlConfiguration y = new YamlConfiguration();
        for (MuteEntry e : mutes.values()) {
            if (e.isExpired()) continue;
            String key = e.uuid.toString();
            y.set(key + ".name", e.name);
            y.set(key + ".until", e.untilEpochMs);
            y.set(key + ".reason", e.reason);
        }
        try {
            plugin.getDataFolder().mkdirs();
            y.save(file);
        } catch (IOException ignored) {}
    }

    public OfflinePlayer findOfflineByName(String name) {
        if (name == null) return null;
        for (OfflinePlayer p : Bukkit.getOfflinePlayers()) {
            if (p.getName() != null && p.getName().equalsIgnoreCase(name)) return p;
        }
        return null;
    }
}
