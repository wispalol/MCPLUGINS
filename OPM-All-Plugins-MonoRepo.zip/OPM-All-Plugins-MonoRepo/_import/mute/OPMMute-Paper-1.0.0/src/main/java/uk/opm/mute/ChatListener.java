package uk.opm.mute;

import io.papermc.paper.event.player.AsyncChatEvent;
import net.kyori.adventure.text.Component;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import uk.opm.mute.data.MuteEntry;
import uk.opm.mute.util.Msg;

public final class ChatListener implements Listener {

    private final OPMMutePlugin plugin;

    public ChatListener(OPMMutePlugin plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onChat(AsyncChatEvent event) {
        Player p = event.getPlayer();
        if (p.hasPermission("opmmute.bypass")) return;

        MuteEntry mute = plugin.store().getMute(p.getUniqueId());
        if (mute == null) return;

        if (mute.isExpired()) {
            plugin.store().removeMute(p.getUniqueId());
            return;
        }

        event.setCancelled(true); // stops message showing in chat

        String key = mute.isPermanent() ? "messages.muted-permanent" : "messages.muted";
        String time = mute.isPermanent() ? "permanent" : Msg.formatDuration(mute.timeLeftSeconds());
        String reason = (mute.reason == null || mute.reason.isBlank()) ? "No reason" : mute.reason;

        String msg = Msg.color(plugin.getConfig().getString(key, "&cYou are muted."))
                .replace("{time}", time)
                .replace("{reason}", reason);

        p.sendMessage(Component.text(msg));
    }
}
