package uk.opm.mute.util;

import org.bukkit.ChatColor;

public final class Msg {
    private Msg() {}

    public static String color(String s) {
        return ChatColor.translateAlternateColorCodes('&', s == null ? "" : s);
    }

    public static String formatDuration(long seconds) {
        if (seconds <= 0) return "0s";
        long s = seconds;

        long days = s / 86400; s %= 86400;
        long hours = s / 3600; s %= 3600;
        long mins = s / 60; s %= 60;

        StringBuilder out = new StringBuilder();
        if (days > 0) out.append(days).append("d ");
        if (hours > 0) out.append(hours).append("h ");
        if (mins > 0) out.append(mins).append("m ");
        if (s > 0 || out.length() == 0) out.append(s).append("s");
        return out.toString().trim();
    }
}
