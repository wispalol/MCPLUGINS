# OPMMute (Paper) 1.0.0

Timed mute plugin for Paper 1.21.x.

## Commands
- `/mute <player> <duration> [reason]`  (example: `/mute opmsamuel 5m spamming`)
- `/unmute <player>`
- `/mutelist`

## Duration format
- `30s`, `5m`, `2h`, `1d`, `perm`

## Build
```bash
mvn clean package
```
Jar: `target/OPMMute-1.0.0.jar`
