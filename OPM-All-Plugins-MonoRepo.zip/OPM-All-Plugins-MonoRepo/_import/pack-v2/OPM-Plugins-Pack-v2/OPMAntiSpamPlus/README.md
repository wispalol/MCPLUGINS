# OPMAntiSpamPlus

Cooldown, duplicates, caps, link filter + /slowchat.

Build: mvn clean package
