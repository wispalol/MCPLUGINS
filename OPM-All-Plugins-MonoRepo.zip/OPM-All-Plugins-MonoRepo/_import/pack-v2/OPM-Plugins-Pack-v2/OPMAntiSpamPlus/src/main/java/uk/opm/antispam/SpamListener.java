package uk.opm.antispam;

import io.papermc.paper.event.player.AsyncChatEvent;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.serializer.plain.PlainTextComponentSerializer;
import org.bukkit.ChatColor;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

public final class SpamListener implements Listener {
    private static final PlainTextComponentSerializer PLAIN = PlainTextComponentSerializer.plainText();
    private final OPMAntiSpamPlusPlugin plugin;
    private final Map<UUID, Long> lastChat = new ConcurrentHashMap<>();
    private final Map<UUID, MsgRec> lastMsg = new ConcurrentHashMap<>();

    public SpamListener(OPMAntiSpamPlusPlugin plugin) { this.plugin = plugin; }

    @EventHandler
    public void onChat(AsyncChatEvent e) {
        FileConfiguration c = plugin.getConfig();
        if (!c.getBoolean("enabled", true)) return;

        Player p = e.getPlayer();
        if (p.hasPermission("opmspam.bypass")) return;

        String msg = PLAIN.serialize(e.message());
        long now = System.currentTimeMillis();

        int slow = plugin.slowChatSeconds();
        if (slow > 0) {
            long last = lastChat.getOrDefault(p.getUniqueId(), 0L);
            if (now - last < slow * 1000L) { block(p, e); return; }
        }

        int cd = c.getInt("cooldown-seconds", 2);
        long last = lastChat.getOrDefault(p.getUniqueId(), 0L);
        if (now - last < cd * 1000L) { block(p, e); return; }

        if (c.getBoolean("block-duplicates", true)) {
            int win = c.getInt("duplicate-window-seconds", 10);
            MsgRec rec = lastMsg.get(p.getUniqueId());
            if (rec != null && now - rec.timeMs < win * 1000L && rec.msg.equalsIgnoreCase(msg)) { block(p, e); return; }
        }

        if (c.getBoolean("caps.enabled", true)) {
            int minLen = c.getInt("caps.min-length", 8);
            int maxPct = c.getInt("caps.max-percent", 70);
            if (msg.length() >= minLen) {
                int letters = 0, caps = 0;
                for (char ch : msg.toCharArray()) {
                    if (Character.isLetter(ch)) { letters++; if (Character.isUpperCase(ch)) caps++; }
                }
                if (letters >= minLen) {
                    int pct = (int)Math.round((caps * 100.0) / Math.max(1, letters));
                    if (pct > maxPct) { block(p, e); return; }
                }
            }
        }

        if (c.getBoolean("links.enabled", true)) {
            String lower = msg.toLowerCase();
            boolean looks = lower.contains("http://") || lower.contains("https://") || lower.contains("www.") ||
                    lower.contains(".com") || lower.contains(".net") || lower.contains(".gg");
            if (looks) {
                boolean ok = false;
                for (String allowed : c.getStringList("links.allowlist")) {
                    if (allowed != null && !allowed.isBlank() && lower.contains(allowed.toLowerCase())) { ok = true; break; }
                }
                if (!ok) { block(p, e); return; }
            }
        }

        lastChat.put(p.getUniqueId(), now);
        lastMsg.put(p.getUniqueId(), new MsgRec(now, msg));
    }

    private void block(Player p, AsyncChatEvent e) {
        e.setCancelled(true);
        String m = plugin.getConfig().getString("messages.blocked", "&cPlease slow down.");
        p.sendMessage(Component.text(ChatColor.translateAlternateColorCodes('&', m)));
    }

    private record MsgRec(long timeMs, String msg) {}
}
