package uk.opm.antispam;

import org.bukkit.plugin.java.JavaPlugin;

public final class OPMAntiSpamPlusPlugin extends JavaPlugin {
    private volatile int slowChatSeconds = 0;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        getServer().getPluginManager().registerEvents(new SpamListener(this), this);

        if (getCommand("slowchat") != null) getCommand("slowchat").setExecutor((sender, cmd, label, args) -> {
            if (!sender.hasPermission("opmspam.slowchat")) return true;
            if (args.length < 1) { sender.sendMessage("§e/slowchat <seconds>"); return true; }
            try { slowChatSeconds = Math.max(0, Integer.parseInt(args[0])); }
            catch (NumberFormatException e) { sender.sendMessage("§cInvalid number."); return true; }
            sender.sendMessage("§aSlow chat set to " + slowChatSeconds + "s");
            return true;
        });
    }

    public int slowChatSeconds() { return slowChatSeconds; }
}
