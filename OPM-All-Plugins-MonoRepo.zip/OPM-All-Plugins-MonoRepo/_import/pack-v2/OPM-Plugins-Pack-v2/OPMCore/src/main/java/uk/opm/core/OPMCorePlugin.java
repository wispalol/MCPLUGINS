package uk.opm.core;

import org.bukkit.plugin.java.JavaPlugin;

public final class OPMCorePlugin extends JavaPlugin {
    @Override
    public void onEnable() {
        saveDefaultConfig();
        if (getCommand("opmcore") != null) getCommand("opmcore").setExecutor((sender, cmd, label, args) -> {
            if (args.length > 0 && args[0].equalsIgnoreCase("reload")) {
                if (!sender.hasPermission("opmcore.reload")) return true;
                reloadConfig();
                sender.sendMessage("§aOPMCore reloaded.");
                return true;
            }
            sender.sendMessage("§e/opmcore reload");
            return true;
        });
    }
}
