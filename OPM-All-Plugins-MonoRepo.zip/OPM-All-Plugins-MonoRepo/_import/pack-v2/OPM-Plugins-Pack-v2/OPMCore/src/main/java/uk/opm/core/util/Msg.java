package uk.opm.core.util;

import org.bukkit.ChatColor;

public final class Msg {
    private Msg() {}
    public static String c(String s) { return ChatColor.translateAlternateColorCodes('&', s == null ? "" : s); }
}
