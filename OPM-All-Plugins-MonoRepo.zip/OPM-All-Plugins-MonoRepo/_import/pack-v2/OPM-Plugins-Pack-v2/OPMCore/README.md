# OPMCore

Core utilities. Command: /opmcore reload

Build: mvn clean package
