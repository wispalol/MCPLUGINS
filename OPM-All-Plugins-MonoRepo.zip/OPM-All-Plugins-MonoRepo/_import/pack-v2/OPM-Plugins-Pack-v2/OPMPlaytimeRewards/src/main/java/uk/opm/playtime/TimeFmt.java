package uk.opm.playtime;

public final class TimeFmt {
    private TimeFmt() {}
    public static String format(long seconds) {
        long s = Math.max(0, seconds);
        long d = s / 86400; s %= 86400;
        long h = s / 3600; s %= 3600;
        long m = s / 60; s %= 60;
        StringBuilder b = new StringBuilder();
        if (d > 0) b.append(d).append("d ");
        if (h > 0) b.append(h).append("h ");
        if (m > 0) b.append(m).append("m ");
        b.append(s).append("s");
        return b.toString().trim();
    }
}
