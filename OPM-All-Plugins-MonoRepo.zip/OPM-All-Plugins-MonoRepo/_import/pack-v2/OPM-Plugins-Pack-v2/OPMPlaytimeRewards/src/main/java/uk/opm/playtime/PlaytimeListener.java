package uk.opm.playtime;

import org.bukkit.Bukkit;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

public final class PlaytimeListener implements Listener {
    private final OPMPlaytimeRewardsPlugin plugin;
    private final Map<UUID, Long> joinMs = new ConcurrentHashMap<>();

    public PlaytimeListener(OPMPlaytimeRewardsPlugin plugin) { this.plugin = plugin; }

    @EventHandler public void onJoin(PlayerJoinEvent e) { joinMs.put(e.getPlayer().getUniqueId(), System.currentTimeMillis()); }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        Player p = e.getPlayer();
        UUID u = p.getUniqueId();
        Long ms = joinMs.remove(u);
        if (ms != null) {
            long add = Math.max(0, (System.currentTimeMillis() - ms) / 1000L);
            plugin.store().addSeconds(u, add);
            maybeReward(p, plugin.store().getSeconds(u));
        }
    }

    private void maybeReward(Player p, long totalSeconds) {
        if (p.hasPermission("opmplaytime.bypassrewards")) return;
        long totalMinutes = totalSeconds / 60L;

        ConfigurationSection sec = plugin.getConfig().getConfigurationSection("rewards");
        if (sec == null) return;

        for (String k : sec.getKeys(false)) {
            try {
                long mins = Long.parseLong(k);
                if (totalMinutes >= mins && !plugin.store().hasGiven(p.getUniqueId(), mins)) {
                    for (String cmd : sec.getStringList(k)) {
                        Bukkit.dispatchCommand(Bukkit.getConsoleSender(), cmd.replace("{player}", p.getName()));
                    }
                    plugin.store().markGiven(p.getUniqueId(), mins);
                }
            } catch (NumberFormatException ignored) {}
        }
    }
}
