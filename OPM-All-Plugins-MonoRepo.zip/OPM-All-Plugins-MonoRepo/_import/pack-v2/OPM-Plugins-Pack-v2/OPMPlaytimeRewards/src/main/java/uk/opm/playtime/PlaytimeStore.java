package uk.opm.playtime;

import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.File;
import java.io.IOException;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

public final class PlaytimeStore {
    private final JavaPlugin plugin;
    private final File file;
    private final Map<UUID, Long> seconds = new ConcurrentHashMap<>();
    private final Map<UUID, Set<Long>> given = new ConcurrentHashMap<>();

    public PlaytimeStore(JavaPlugin plugin) {
        this.plugin = plugin;
        this.file = new File(plugin.getDataFolder(), "playtime.yml");
    }

    public long getSeconds(UUID u) { return seconds.getOrDefault(u, 0L); }
    public void addSeconds(UUID u, long add) { seconds.put(u, getSeconds(u) + Math.max(0, add)); }

    public boolean hasGiven(UUID u, long mins) { return given.getOrDefault(u, Set.of()).contains(mins); }
    public void markGiven(UUID u, long mins) { given.computeIfAbsent(u, k -> ConcurrentHashMap.newKeySet()).add(mins); save(); }

    public void load() {
        if (!file.exists()) return;
        YamlConfiguration y = YamlConfiguration.loadConfiguration(file);
        for (String k : y.getKeys(false)) {
            try {
                UUID u = UUID.fromString(k);
                seconds.put(u, y.getLong(k + ".seconds", 0L));
                Set<Long> s = ConcurrentHashMap.newKeySet();
                for (String g : y.getStringList(k + ".given")) {
                    try { s.add(Long.parseLong(g)); } catch (Exception ignored) {}
                }
                given.put(u, s);
            } catch (Exception ignored) {}
        }
    }

    public void save() {
        YamlConfiguration y = new YamlConfiguration();
        for (UUID u : seconds.keySet()) {
            y.set(u.toString() + ".seconds", seconds.getOrDefault(u, 0L));
            List<String> g = new ArrayList<>();
            for (Long m : given.getOrDefault(u, Set.of())) g.add(String.valueOf(m));
            y.set(u.toString() + ".given", g);
        }
        try { plugin.getDataFolder().mkdirs(); y.save(file); } catch (IOException ignored) {}
    }
}
