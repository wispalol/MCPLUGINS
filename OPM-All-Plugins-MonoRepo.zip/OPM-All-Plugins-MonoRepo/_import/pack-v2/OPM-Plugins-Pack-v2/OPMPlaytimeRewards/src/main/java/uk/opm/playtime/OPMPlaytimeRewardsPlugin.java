package uk.opm.playtime;

import org.bukkit.Bukkit;
import org.bukkit.command.PluginCommand;
import org.bukkit.plugin.java.JavaPlugin;

public final class OPMPlaytimeRewardsPlugin extends JavaPlugin {
    private PlaytimeStore store;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        store = new PlaytimeStore(this);
        store.load();

        getServer().getPluginManager().registerEvents(new PlaytimeListener(this), this);

        PluginCommand cmd = getCommand("playtime");
        if (cmd != null) cmd.setExecutor((sender, c, l, a) -> {
            if (!(sender instanceof org.bukkit.entity.Player p)) return true;
            long seconds = store.getSeconds(p.getUniqueId());
            p.sendMessage("§ePlaytime: §f" + TimeFmt.format(seconds));
            return true;
        });

        long minutes = Math.max(1, getConfig().getLong("save-interval-minutes", 5));
        Bukkit.getScheduler().runTaskTimerAsynchronously(this, store::save, minutes*60L*20L, minutes*60L*20L);
    }

    @Override
    public void onDisable() {
        if (store != null) store.save();
    }

    public PlaytimeStore store() { return store; }
}
