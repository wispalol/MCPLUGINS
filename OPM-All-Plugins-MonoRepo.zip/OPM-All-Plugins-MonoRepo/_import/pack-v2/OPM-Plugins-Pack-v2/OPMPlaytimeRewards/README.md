# OPMPlaytimeRewards

Tracks playtime + runs reward commands at milestones.

Build: mvn clean package
