package uk.opm.staff;

import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public final class StaffChatCommand implements CommandExecutor {
    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!sender.hasPermission("opmstaff.staffchat")) return true;
        if (args.length == 0) { sender.sendMessage("§cUsage: /staffchat <message>"); return true; }
        String msg = String.join(" ", args);
        String line = "§6[Staff] §e" + sender.getName() + "§7: §f" + msg;
        for (Player p : Bukkit.getOnlinePlayers()) if (p.hasPermission("opmstaff.staffchat")) p.sendMessage(line);
        Bukkit.getConsoleSender().sendMessage(line);
        return true;
    }
}
