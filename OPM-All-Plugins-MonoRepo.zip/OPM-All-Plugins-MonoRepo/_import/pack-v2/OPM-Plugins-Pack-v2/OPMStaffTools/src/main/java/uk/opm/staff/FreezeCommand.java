package uk.opm.staff;

import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public final class FreezeCommand implements CommandExecutor {
    private final OPMStaffToolsPlugin plugin;
    public FreezeCommand(OPMStaffToolsPlugin plugin) { this.plugin = plugin; }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!sender.hasPermission("opmstaff.freeze")) return true;
        if (args.length < 1) { sender.sendMessage("§cUsage: /freeze <player>"); return true; }
        Player t = plugin.getServer().getPlayerExact(args[0]);
        if (t == null) { sender.sendMessage("§cPlayer not found."); return true; }
        boolean frozen = FreezeStore.toggle(t.getUniqueId());
        sender.sendMessage(frozen ? "§aFrozen " + t.getName() : "§aUnfrozen " + t.getName());
        t.sendMessage(frozen ? "§cYou have been frozen by staff." : "§aYou are no longer frozen.");
        return true;
    }
}
