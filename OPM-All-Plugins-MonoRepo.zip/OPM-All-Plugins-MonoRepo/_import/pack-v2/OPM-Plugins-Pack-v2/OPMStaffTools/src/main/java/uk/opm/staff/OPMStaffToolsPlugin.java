package uk.opm.staff;

import org.bukkit.plugin.java.JavaPlugin;

public final class OPMStaffToolsPlugin extends JavaPlugin {
    @Override
    public void onEnable() {
        getServer().getPluginManager().registerEvents(new FreezeListener(), this);
        if (getCommand("freeze") != null) getCommand("freeze").setExecutor(new FreezeCommand(this));
        if (getCommand("staffchat") != null) getCommand("staffchat").setExecutor(new StaffChatCommand());
    }
}
