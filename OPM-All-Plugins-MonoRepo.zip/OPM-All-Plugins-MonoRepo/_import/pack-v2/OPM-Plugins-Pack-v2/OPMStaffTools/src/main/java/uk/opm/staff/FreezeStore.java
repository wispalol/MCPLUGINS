package uk.opm.staff;

import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

public final class FreezeStore {
    private static final Set<UUID> FROZEN = ConcurrentHashMap.newKeySet();
    private FreezeStore() {}
    public static boolean toggle(UUID u) { if (FROZEN.remove(u)) return false; FROZEN.add(u); return true; }
    public static boolean isFrozen(UUID u) { return FROZEN.contains(u); }
}
