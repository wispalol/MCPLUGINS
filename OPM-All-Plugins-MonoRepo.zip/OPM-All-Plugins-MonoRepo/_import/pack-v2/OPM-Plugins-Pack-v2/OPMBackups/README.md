# OPMBackups

Scheduled zip world backups + /backup now.

Build: mvn clean package
