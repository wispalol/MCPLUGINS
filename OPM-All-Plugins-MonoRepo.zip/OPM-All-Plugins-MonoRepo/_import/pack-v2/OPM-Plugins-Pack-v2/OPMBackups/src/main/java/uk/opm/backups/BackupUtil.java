package uk.opm.backups;

import org.bukkit.Server;
import org.bukkit.World;

import java.io.*;
import java.nio.file.Files;
import java.util.Arrays;
import java.util.Comparator;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

public final class BackupUtil {
    private BackupUtil() {}

    public static void zipWorlds(Server server, File zipFile) throws IOException {
        try (ZipOutputStream zos = new ZipOutputStream(new BufferedOutputStream(new FileOutputStream(zipFile)))) {
            for (World w : server.getWorlds()) {
                File folder = w.getWorldFolder();
                zipFolder(folder, folder.getName() + "/", zos);
            }
        }
    }

    private static void zipFolder(File folder, String basePath, ZipOutputStream zos) throws IOException {
        File[] files = folder.listFiles();
        if (files == null) return;
        for (File f : files) {
            if (f.getName().equalsIgnoreCase("session.lock")) continue;
            if (f.isDirectory()) {
                zipFolder(f, basePath + f.getName() + "/", zos);
            } else {
                zos.putNextEntry(new ZipEntry(basePath + f.getName()));
                Files.copy(f.toPath(), zos);
                zos.closeEntry();
            }
        }
    }

    public static void pruneOld(File dir, int keepLast) {
        File[] zips = dir.listFiles((d, n) -> n.toLowerCase().endsWith(".zip"));
        if (zips == null) return;
        Arrays.sort(zips, Comparator.comparingLong(File::lastModified).reversed());
        for (int i = keepLast; i < zips.length; i++) {
            try { zips[i].delete(); } catch (Exception ignored) {}
        }
    }
}
