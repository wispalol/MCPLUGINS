package uk.opm.backups;

import org.bukkit.Bukkit;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.File;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public final class OPMBackupsPlugin extends JavaPlugin {
    private static final DateTimeFormatter FMT = DateTimeFormatter.ofPattern("yyyy-MM-dd_HH-mm-ss");

    @Override
    public void onEnable() {
        saveDefaultConfig();
        if (!getConfig().getBoolean("enabled", true)) return;

        if (getCommand("backup") != null) getCommand("backup").setExecutor((sender, cmd, label, args) -> {
            if (!sender.hasPermission("opmbackups.run")) return true;
            if (args.length == 0 || !args[0].equalsIgnoreCase("now")) { sender.sendMessage("§e/backup now"); return true; }
            Bukkit.getScheduler().runTaskAsynchronously(this, () -> runBackup("manual"));
            sender.sendMessage("§aBackup started.");
            return true;
        });

        long minutes = Math.max(1, getConfig().getLong("interval-minutes", 120));
        long ticks = minutes * 60L * 20L;
        Bukkit.getScheduler().runTaskTimerAsynchronously(this, () -> runBackup("scheduled"), ticks, ticks);
    }

    private void runBackup(String reason) {
        try {
            String folderName = getConfig().getString("backup-folder", "backups");
            File outDir = new File(getDataFolder(), folderName);
            outDir.mkdirs();
            String stamp = LocalDateTime.now().format(FMT);
            File zip = new File(outDir, "backup_" + stamp + "_" + reason + ".zip");
            BackupUtil.zipWorlds(getServer(), zip);
            BackupUtil.pruneOld(outDir, Math.max(1, getConfig().getInt("keep-last", 10)));
            getLogger().info("Backup created: " + zip.getName());
        } catch (Exception e) {
            getLogger().severe("Backup failed: " + e.getMessage());
        }
    }
}
