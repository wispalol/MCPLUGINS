package uk.opm.death;

import net.kyori.adventure.text.Component;
import org.bukkit.ChatColor;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.PlayerDeathEvent;

public final class DeathListener implements Listener {
    private final OPMDeathMessagesPlusPlugin plugin;
    public DeathListener(OPMDeathMessagesPlusPlugin plugin) { this.plugin = plugin; }

    @EventHandler
    public void onDeath(PlayerDeathEvent e) {
        FileConfiguration c = plugin.getConfig();
        if (!c.getBoolean("enabled", true)) return;

        String msg = e.getDeathMessage();
        if (msg == null) msg = e.getPlayer().getName() + " died";

        String format = c.getString("broadcast-format", "&c☠ &f{msg}");
        e.setDeathMessage(ChatColor.translateAlternateColorCodes('&', format.replace("{msg}", msg)));

        if (c.getBoolean("send-death-coords", true)) {
            Player p = e.getPlayer();
            if (!p.hasPermission("opmdeath.coords")) return;
            var loc = p.getLocation();
            String cm = c.getString("coords-message", "&eYou died at X:{x} Y:{y} Z:{z} ({world})");
            cm = cm.replace("{x}", String.valueOf(loc.getBlockX()))
                   .replace("{y}", String.valueOf(loc.getBlockY()))
                   .replace("{z}", String.valueOf(loc.getBlockZ()))
                   .replace("{world}", p.getWorld().getName());
            p.sendMessage(Component.text(ChatColor.translateAlternateColorCodes('&', cm)));
        }
    }
}
