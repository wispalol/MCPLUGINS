package uk.opm.death;

import org.bukkit.plugin.java.JavaPlugin;

public final class OPMDeathMessagesPlusPlugin extends JavaPlugin {
    @Override
    public void onEnable() {
        saveDefaultConfig();
        getServer().getPluginManager().registerEvents(new DeathListener(this), this);
    }
}
