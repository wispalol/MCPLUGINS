# OPMDeathMessagesPlus

Formats death messages + optional coords message.

Build: mvn clean package
