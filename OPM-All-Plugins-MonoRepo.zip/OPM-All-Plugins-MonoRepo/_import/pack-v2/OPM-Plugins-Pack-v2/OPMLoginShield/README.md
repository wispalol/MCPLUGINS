# OPMLoginShield

Join rate limiter per IP + optional simple captcha.

Build: mvn clean package
