package uk.opm.loginshield;

import io.papermc.paper.event.player.AsyncChatEvent;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.serializer.plain.PlainTextComponentSerializer;
import org.bukkit.ChatColor;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;

import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

public final class CaptchaListener implements Listener {
    private static final PlainTextComponentSerializer PLAIN = PlainTextComponentSerializer.plainText();
    private final OPMLoginShieldPlugin plugin;
    private final Set<UUID> pending = ConcurrentHashMap.newKeySet();

    public CaptchaListener(OPMLoginShieldPlugin plugin) { this.plugin = plugin; }

    @EventHandler
    public void onJoin(PlayerJoinEvent e) {
        FileConfiguration c = plugin.getConfig();
        if (!c.getBoolean("captcha.enabled", false)) return;
        Player p = e.getPlayer();
        pending.add(p.getUniqueId());
        String code = c.getString("captcha.code", "I am human");
        String prompt = c.getString("captcha.prompt", "&eType: &f{code} &eto speak.");
        p.sendMessage(Component.text(color(prompt.replace("{code}", code))));
    }

    @EventHandler
    public void onChat(AsyncChatEvent e) {
        FileConfiguration c = plugin.getConfig();
        if (!c.getBoolean("captcha.enabled", false)) return;

        Player p = e.getPlayer();
        if (!pending.contains(p.getUniqueId())) return;

        String code = c.getString("captcha.code", "I am human");
        String fail = c.getString("captcha.fail-kick", "&cCaptcha failed.");
        String msg = PLAIN.serialize(e.message());

        e.setCancelled(true);
        pending.remove(p.getUniqueId());

        if (msg.equalsIgnoreCase(code)) {
            p.sendMessage(Component.text("§aVerified."));
        } else {
            plugin.getServer().getScheduler().runTask(plugin, () -> p.kick(Component.text(color(fail))));
        }
    }

    private static String color(String s) { return ChatColor.translateAlternateColorCodes('&', s == null ? "" : s); }
}
