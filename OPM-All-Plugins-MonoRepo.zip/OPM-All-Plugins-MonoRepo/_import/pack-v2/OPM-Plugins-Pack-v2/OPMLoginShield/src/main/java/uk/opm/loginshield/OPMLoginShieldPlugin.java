package uk.opm.loginshield;

import org.bukkit.plugin.java.JavaPlugin;

public final class OPMLoginShieldPlugin extends JavaPlugin {
    @Override
    public void onEnable() {
        saveDefaultConfig();
        if (!getConfig().getBoolean("enabled", true)) return;
        getServer().getPluginManager().registerEvents(new RateLimitListener(this), this);
        getServer().getPluginManager().registerEvents(new CaptchaListener(this), this);
    }
}
