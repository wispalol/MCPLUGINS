package uk.opm.loginshield;

import net.kyori.adventure.text.Component;
import org.bukkit.ChatColor;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.AsyncPlayerPreLoginEvent;

import java.net.InetAddress;
import java.util.Deque;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentLinkedDeque;

public final class RateLimitListener implements Listener {
    private final OPMLoginShieldPlugin plugin;
    private final Map<String, Deque<Long>> ipJoins = new ConcurrentHashMap<>();
    private final Deque<Long> globalJoins = new ConcurrentLinkedDeque<>();

    public RateLimitListener(OPMLoginShieldPlugin plugin) { this.plugin = plugin; }

    @EventHandler
    public void onPreLogin(AsyncPlayerPreLoginEvent e) {
        FileConfiguration c = plugin.getConfig();
        int perIp = c.getInt("rate-limit.per-ip-per-10s", 3);
        int global = c.getInt("rate-limit.global-per-10s", 15);
        String msg = c.getString("rate-limit.kick-message", "&cToo many joins.");
        long now = System.currentTimeMillis();
        long window = 10_000L;

        cleanup(globalJoins, now, window);
        if (globalJoins.size() >= global) {
            e.disallow(AsyncPlayerPreLoginEvent.Result.KICK_OTHER, Component.text(color(msg)));
            return;
        }
        globalJoins.addLast(now);

        InetAddress addr = e.getAddress();
        String ip = addr == null ? "unknown" : addr.getHostAddress();
        Deque<Long> q = ipJoins.computeIfAbsent(ip, k -> new ConcurrentLinkedDeque<>());
        cleanup(q, now, window);
        if (q.size() >= perIp) {
            e.disallow(AsyncPlayerPreLoginEvent.Result.KICK_OTHER, Component.text(color(msg)));
            return;
        }
        q.addLast(now);
    }

    private static void cleanup(Deque<Long> q, long now, long window) {
        while (!q.isEmpty() && now - q.peekFirst() > window) q.pollFirst();
    }
    private static String color(String s) { return ChatColor.translateAlternateColorCodes('&', s == null ? "" : s); }
}
