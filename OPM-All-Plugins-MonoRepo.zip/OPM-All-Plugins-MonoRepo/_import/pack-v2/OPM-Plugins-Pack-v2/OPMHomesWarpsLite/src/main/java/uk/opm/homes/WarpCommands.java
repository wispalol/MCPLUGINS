package uk.opm.homes;

import net.kyori.adventure.text.Component;
import org.bukkit.ChatColor;
import org.bukkit.Location;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public final class WarpCommands implements CommandExecutor {
    enum Mode { SET, TP, DEL }
    private final OPMHomesWarpsLitePlugin plugin;
    private final Mode mode;
    public WarpCommands(OPMHomesWarpsLitePlugin plugin, Mode mode) { this.plugin = plugin; this.mode = mode; }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player p)) return true;
        if (args.length < 1) { p.sendMessage(Component.text("§cUsage: /" + label + " <name>")); return true; }

        String name = args[0];
        if (mode == Mode.SET) {
            if (!p.hasPermission("opmhomes.setwarp")) return true;
            plugin.store().setWarp(name, p.getLocation());
            p.sendMessage(Component.text("§aWarp set: " + name));
            return true;
        }
        if (mode == Mode.DEL) {
            if (!p.hasPermission("opmhomes.delwarp")) return true;
            boolean ok = plugin.store().delWarp(name);
            p.sendMessage(Component.text(ok ? "§aWarp deleted." : "§cWarp not found."));
            return true;
        }
        Location w = plugin.store().getWarp(name);
        if (w == null) {
            p.sendMessage(Component.text("§cWarp not found. Available: §7" + String.join(", ", plugin.store().warpNames())));
            return true;
        }
        p.teleportAsync(w);
        p.sendMessage(Component.text(color(plugin.getConfig().getString("messages.warped", "&aTeleported."))));
        return true;
    }

    private static String color(String s) { return ChatColor.translateAlternateColorCodes('&', s == null ? "" : s); }
}
