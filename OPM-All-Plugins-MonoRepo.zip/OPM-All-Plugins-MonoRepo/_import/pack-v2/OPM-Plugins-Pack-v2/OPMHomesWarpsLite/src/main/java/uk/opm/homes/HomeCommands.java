package uk.opm.homes;

import net.kyori.adventure.text.Component;
import org.bukkit.ChatColor;
import org.bukkit.Location;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public final class HomeCommands implements CommandExecutor {
    private final OPMHomesWarpsLitePlugin plugin;
    private final boolean set;
    public HomeCommands(OPMHomesWarpsLitePlugin plugin, boolean set) { this.plugin = plugin; this.set = set; }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player p)) return true;
        if (set) {
            plugin.store().setHome(p.getUniqueId(), p.getLocation());
            p.sendMessage(Component.text("§aHome set."));
            return true;
        }
        Location home = plugin.store().getHome(p.getUniqueId());
        if (home == null) {
            p.sendMessage(Component.text(color(plugin.getConfig().getString("messages.no-home", "&cYou don't have a home set."))));
            return true;
        }
        p.teleportAsync(home);
        p.sendMessage(Component.text(color(plugin.getConfig().getString("messages.warped", "&aTeleported."))));
        return true;
    }

    private static String color(String s) { return ChatColor.translateAlternateColorCodes('&', s == null ? "" : s); }
}
