package uk.opm.homes;

import org.bukkit.plugin.java.JavaPlugin;

public final class OPMHomesWarpsLitePlugin extends JavaPlugin {
    private TeleportStore store;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        store = new TeleportStore(this);
        store.load();

        if (getCommand("sethome") != null) getCommand("sethome").setExecutor(new HomeCommands(this, true));
        if (getCommand("home") != null) getCommand("home").setExecutor(new HomeCommands(this, false));
        if (getCommand("setwarp") != null) getCommand("setwarp").setExecutor(new WarpCommands(this, WarpCommands.Mode.SET));
        if (getCommand("warp") != null) getCommand("warp").setExecutor(new WarpCommands(this, WarpCommands.Mode.TP));
        if (getCommand("delwarp") != null) getCommand("delwarp").setExecutor(new WarpCommands(this, WarpCommands.Mode.DEL));
    }

    @Override
    public void onDisable() {
        if (store != null) store.save();
    }

    public TeleportStore store() { return store; }
}
