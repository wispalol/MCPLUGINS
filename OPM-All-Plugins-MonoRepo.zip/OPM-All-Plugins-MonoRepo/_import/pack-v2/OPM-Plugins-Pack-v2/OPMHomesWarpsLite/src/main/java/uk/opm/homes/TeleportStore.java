package uk.opm.homes;

import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.File;
import java.io.IOException;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

public final class TeleportStore {
    private final JavaPlugin plugin;
    private final File file;
    private final Map<UUID, Location> homes = new ConcurrentHashMap<>();
    private final Map<String, Location> warps = new ConcurrentHashMap<>();

    public TeleportStore(JavaPlugin plugin) {
        this.plugin = plugin;
        this.file = new File(plugin.getDataFolder(), "teleports.yml");
    }

    public Location getHome(UUID u) { return homes.get(u); }
    public void setHome(UUID u, Location loc) { homes.put(u, loc); save(); }

    public Location getWarp(String name) { return warps.get(name.toLowerCase()); }
    public void setWarp(String name, Location loc) { warps.put(name.toLowerCase(), loc); save(); }
    public boolean delWarp(String name) { boolean ok = warps.remove(name.toLowerCase()) != null; if (ok) save(); return ok; }
    public Set<String> warpNames() { return new TreeSet<>(warps.keySet()); }

    public void load() {
        if (!file.exists()) return;
        YamlConfiguration y = YamlConfiguration.loadConfiguration(file);

        var h = y.getConfigurationSection("homes");
        if (h != null) for (String k : h.getKeys(false)) {
            try {
                UUID u = UUID.fromString(k);
                Location loc = readLoc(y, "homes." + k);
                if (loc != null) homes.put(u, loc);
            } catch (Exception ignored) {}
        }

        var w = y.getConfigurationSection("warps");
        if (w != null) for (String k : w.getKeys(false)) {
            Location loc = readLoc(y, "warps." + k);
            if (loc != null) warps.put(k.toLowerCase(), loc);
        }
    }

    public void save() {
        YamlConfiguration y = new YamlConfiguration();
        for (Map.Entry<UUID, Location> e : homes.entrySet()) writeLoc(y, "homes." + e.getKey(), e.getValue());
        for (Map.Entry<String, Location> e : warps.entrySet()) writeLoc(y, "warps." + e.getKey(), e.getValue());

        try { plugin.getDataFolder().mkdirs(); y.save(file); } catch (IOException ignored) {}
    }

    private Location readLoc(YamlConfiguration y, String path) {
        String worldName = y.getString(path + ".world");
        World world = worldName == null ? null : plugin.getServer().getWorld(worldName);
        if (world == null) return null;
        double x = y.getDouble(path + ".x");
        double yy = y.getDouble(path + ".y");
        double z = y.getDouble(path + ".z");
        float yaw = (float)y.getDouble(path + ".yaw");
        float pitch = (float)y.getDouble(path + ".pitch");
        return new Location(world, x, yy, z, yaw, pitch);
    }

    private void writeLoc(YamlConfiguration y, String path, Location loc) {
        y.set(path + ".world", loc.getWorld().getName());
        y.set(path + ".x", loc.getX());
        y.set(path + ".y", loc.getY());
        y.set(path + ".z", loc.getZ());
        y.set(path + ".yaw", loc.getYaw());
        y.set(path + ".pitch", loc.getPitch());
    }
}
