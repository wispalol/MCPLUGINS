# OPMAFK

AFK detection + optional kick.

Build: mvn clean package
