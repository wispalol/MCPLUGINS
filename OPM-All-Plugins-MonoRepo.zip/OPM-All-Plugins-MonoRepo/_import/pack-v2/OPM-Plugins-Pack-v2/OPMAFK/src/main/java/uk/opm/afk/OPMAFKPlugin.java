package uk.opm.afk;

import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

public final class OPMAFKPlugin extends JavaPlugin {
    private final Map<UUID, Long> lastActive = new ConcurrentHashMap<>();
    private final Map<UUID, Boolean> isAfk = new ConcurrentHashMap<>();

    @Override
    public void onEnable() {
        saveDefaultConfig();
        getServer().getPluginManager().registerEvents(new ActivityListener(this, lastActive, isAfk), this);

        Bukkit.getScheduler().runTaskTimer(this, () -> {
            if (!getConfig().getBoolean("enabled", true)) return;

            long now = System.currentTimeMillis();
            long afkMs = Math.max(1, getConfig().getLong("afk-minutes", 10)) * 60_000L;
            long kickMs = Math.max(0, getConfig().getLong("kick-minutes", 60)) * 60_000L;

            for (Player p : Bukkit.getOnlinePlayers()) {
                UUID u = p.getUniqueId();
                long last = lastActive.getOrDefault(u, now);
                boolean afk = isAfk.getOrDefault(u, false);

                if (!afk && now - last >= afkMs) {
                    isAfk.put(u, true);
                    p.sendMessage(Component.text(color(getConfig().getString("messages.now-afk", "&7You are now AFK."))));
                }

                if (kickMs > 0 && now - last >= kickMs) {
                    p.kick(Component.text(color(getConfig().getString("messages.kick", "&cKicked for being AFK too long.")))));
                }
            }
        }, 20L, 20L);
    }

    static String color(String s) { return ChatColor.translateAlternateColorCodes('&', s == null ? "" : s); }
}
