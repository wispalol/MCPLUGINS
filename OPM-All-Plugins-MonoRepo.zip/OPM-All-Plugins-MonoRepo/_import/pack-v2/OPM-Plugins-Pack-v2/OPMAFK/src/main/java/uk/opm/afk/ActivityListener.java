package uk.opm.afk;

import net.kyori.adventure.text.Component;
import org.bukkit.ChatColor;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.*;

import java.util.Map;
import java.util.UUID;

public final class ActivityListener implements Listener {
    private final OPMAFKPlugin plugin;
    private final Map<UUID, Long> lastActive;
    private final Map<UUID, Boolean> isAfk;

    public ActivityListener(OPMAFKPlugin plugin, Map<UUID, Long> lastActive, Map<UUID, Boolean> isAfk) {
        this.plugin = plugin;
        this.lastActive = lastActive;
        this.isAfk = isAfk;
    }

    @EventHandler public void onJoin(PlayerJoinEvent e) { touch(e.getPlayer()); }
    @EventHandler public void onQuit(PlayerQuitEvent e) { lastActive.remove(e.getPlayer().getUniqueId()); isAfk.remove(e.getPlayer().getUniqueId()); }
    @EventHandler public void onMove(PlayerMoveEvent e) { if (moved(e)) touch(e.getPlayer()); }
    @EventHandler public void onChat(io.papermc.paper.event.player.AsyncChatEvent e) { touch(e.getPlayer()); }
    @EventHandler public void onInteract(PlayerInteractEvent e) { touch(e.getPlayer()); }
    @EventHandler public void onCommand(PlayerCommandPreprocessEvent e) { touch(e.getPlayer()); }

    private boolean moved(PlayerMoveEvent e) {
        return e.getTo() != null && (e.getFrom().getX() != e.getTo().getX() || e.getFrom().getZ() != e.getTo().getZ() || e.getFrom().getY() != e.getTo().getY());
    }

    private void touch(Player p) {
        UUID u = p.getUniqueId();
        lastActive.put(u, System.currentTimeMillis());
        boolean afk = isAfk.getOrDefault(u, false);
        if (afk) {
            isAfk.put(u, false);
            String msg = plugin.getConfig().getString("messages.no-longer-afk", "&aYou are no longer AFK.");
            p.sendMessage(Component.text(ChatColor.translateAlternateColorCodes('&', msg)));
        }
    }
}
