# OPM Plugins Pack v2 (Paper 1.21.11)

This ZIP contains multiple **GitHub-ready** Paper plugin projects (Maven + Java 21).

## Included (10)
- OPMCore
- OPMLoginShield
- OPMAntiSpamPlus
- OPMStaffTools
- OPMBackups
- OPMGriefGuardLite
- OPMHomesWarpsLite
- OPMAFK
- OPMDeathMessagesPlus
- OPMPlaytimeRewards

## Build any plugin
```bash
mvn clean package
```
Jar will be in `target/`.
