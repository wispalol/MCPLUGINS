package uk.opm.griefguard;

import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.File;
import java.io.IOException;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

public final class ClaimStore {
    private final JavaPlugin plugin;
    private final File file;
    private final Map<ChunkKey, Claim> claims = new ConcurrentHashMap<>();

    public ClaimStore(JavaPlugin plugin) {
        this.plugin = plugin;
        this.file = new File(plugin.getDataFolder(), "claims.yml");
    }

    public Claim get(ChunkKey key) { return claims.get(key); }

    public boolean claim(ChunkKey key, UUID owner) {
        if (claims.containsKey(key)) return false;
        claims.put(key, new Claim(owner));
        save();
        return true;
    }

    public boolean unclaim(ChunkKey key, UUID requester, boolean admin) {
        Claim c = claims.get(key);
        if (c == null) return false;
        if (!admin && !c.owner.equals(requester)) return false;
        claims.remove(key);
        save();
        return true;
    }

    public boolean trust(ChunkKey key, UUID owner, UUID target) {
        Claim c = claims.get(key);
        if (c == null || !c.owner.equals(owner)) return false;
        c.trusted.add(target);
        save();
        return true;
    }

    public boolean untrust(ChunkKey key, UUID owner, UUID target) {
        Claim c = claims.get(key);
        if (c == null || !c.owner.equals(owner)) return false;
        c.trusted.remove(target);
        save();
        return true;
    }

    public void load() {
        if (!file.exists()) return;
        YamlConfiguration y = YamlConfiguration.loadConfiguration(file);
        for (String k : y.getKeys(false)) {
            try {
                String[] parts = k.split(":");
                UUID world = UUID.fromString(parts[0]);
                int x = Integer.parseInt(parts[1]);
                int z = Integer.parseInt(parts[2]);
                UUID owner = UUID.fromString(y.getString(k + ".owner"));
                Claim c = new Claim(owner);
                for (String tu : y.getStringList(k + ".trusted")) c.trusted.add(UUID.fromString(tu));
                claims.put(new ChunkKey(world, x, z), c);
            } catch (Exception ignored) {}
        }
    }

    public void save() {
        YamlConfiguration y = new YamlConfiguration();
        for (Map.Entry<ChunkKey, Claim> e : claims.entrySet()) {
            String k = e.getKey().toString();
            y.set(k + ".owner", e.getValue().owner.toString());
            List<String> t = new ArrayList<>();
            for (UUID u : e.getValue().trusted) t.add(u.toString());
            y.set(k + ".trusted", t);
        }
        try {
            plugin.getDataFolder().mkdirs();
            y.save(file);
        } catch (IOException ignored) {}
    }
}
