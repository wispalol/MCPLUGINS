package uk.opm.griefguard;

import net.kyori.adventure.text.Component;
import org.bukkit.ChatColor;
import org.bukkit.block.Block;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockPlaceEvent;

public final class ProtectListener implements Listener {
    private final OPMGriefGuardLitePlugin plugin;
    public ProtectListener(OPMGriefGuardLitePlugin plugin) { this.plugin = plugin; }

    @EventHandler
    public void onBreak(BlockBreakEvent e) {
        if (!canBuild(e.getPlayer(), e.getBlock())) {
            e.setCancelled(true);
            deny(e.getPlayer());
        }
    }

    @EventHandler
    public void onPlace(BlockPlaceEvent e) {
        if (!canBuild(e.getPlayer(), e.getBlockPlaced())) {
            e.setCancelled(true);
            deny(e.getPlayer());
        }
    }

    private boolean canBuild(Player p, Block b) {
        if (p.hasPermission("opmclaim.admin")) return true;
        Claim c = plugin.store().get(ChunkKey.of(b.getChunk()));
        if (c == null) return true;
        return c.canBuild(p.getUniqueId());
    }

    private void deny(Player p) {
        String m = plugin.getConfig().getString("messages.denied", "&cYou can't build here.");
        p.sendMessage(Component.text(ChatColor.translateAlternateColorCodes('&', m)));
    }
}
