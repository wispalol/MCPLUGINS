package uk.opm.griefguard;

import org.bukkit.OfflinePlayer;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public final class TrustCommands implements CommandExecutor {
    private final OPMGriefGuardLitePlugin plugin;
    private final boolean trust;
    public TrustCommands(OPMGriefGuardLitePlugin plugin, boolean trust) { this.plugin = plugin; this.trust = trust; }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player p)) return true;
        if (args.length < 1) { p.sendMessage("§cUsage: /" + (trust ? "trust" : "untrust") + " <player>"); return true; }

        OfflinePlayer t = plugin.getServer().getOfflinePlayer(args[0]);
        if (t.getUniqueId() == null) { p.sendMessage("§cPlayer not found."); return true; }

        ChunkKey key = ChunkKey.of(p.getLocation().getChunk());
        boolean ok = trust
                ? plugin.store().trust(key, p.getUniqueId(), t.getUniqueId())
                : plugin.store().untrust(key, p.getUniqueId(), t.getUniqueId());

        p.sendMessage(ok ? "§aUpdated trust for this chunk." : "§cYou must own this claimed chunk.");
        return true;
    }
}
