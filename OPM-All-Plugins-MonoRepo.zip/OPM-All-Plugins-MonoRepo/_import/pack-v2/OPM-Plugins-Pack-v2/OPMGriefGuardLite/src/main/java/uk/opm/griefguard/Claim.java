package uk.opm.griefguard;

import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

public final class Claim {
    public UUID owner;
    public final Set<UUID> trusted = new HashSet<>();
    public Claim(UUID owner) { this.owner = owner; }
    public boolean canBuild(UUID u) { return owner.equals(u) || trusted.contains(u); }
}
