package uk.opm.griefguard;

import org.bukkit.plugin.java.JavaPlugin;

public final class OPMGriefGuardLitePlugin extends JavaPlugin {
    private ClaimStore store;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        store = new ClaimStore(this);
        store.load();

        getServer().getPluginManager().registerEvents(new ProtectListener(this), this);

        if (getCommand("claim") != null) getCommand("claim").setExecutor(new ClaimCommands(this, ClaimCommands.Mode.CLAIM));
        if (getCommand("unclaim") != null) getCommand("unclaim").setExecutor(new ClaimCommands(this, ClaimCommands.Mode.UNCLAIM));
        if (getCommand("trust") != null) getCommand("trust").setExecutor(new TrustCommands(this, true));
        if (getCommand("untrust") != null) getCommand("untrust").setExecutor(new TrustCommands(this, false));
    }

    @Override
    public void onDisable() {
        if (store != null) store.save();
    }

    public ClaimStore store() { return store; }
}
