package uk.opm.griefguard;

import org.bukkit.Chunk;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public final class ClaimCommands implements CommandExecutor {
    enum Mode { CLAIM, UNCLAIM }
    private final OPMGriefGuardLitePlugin plugin;
    private final Mode mode;
    public ClaimCommands(OPMGriefGuardLitePlugin plugin, Mode mode) { this.plugin = plugin; this.mode = mode; }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player p)) return true;
        Chunk c = p.getLocation().getChunk();
        ChunkKey key = ChunkKey.of(c);
        if (mode == Mode.CLAIM) {
            boolean ok = plugin.store().claim(key, p.getUniqueId());
            p.sendMessage(ok ? "§aClaimed this chunk." : "§cThis chunk is already claimed.");
        } else {
            boolean admin = p.hasPermission("opmclaim.admin");
            boolean ok = plugin.store().unclaim(key, p.getUniqueId(), admin);
            p.sendMessage(ok ? "§aUnclaimed this chunk." : "§cYou can't unclaim this chunk.");
        }
        return true;
    }
}
