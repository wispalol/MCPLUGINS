package uk.opm.griefguard;

import org.bukkit.Chunk;
import java.util.Objects;
import java.util.UUID;

public final class ChunkKey {
    public final UUID world;
    public final int x;
    public final int z;

    public ChunkKey(UUID world, int x, int z) { this.world = world; this.x = x; this.z = z; }
    public static ChunkKey of(Chunk c) { return new ChunkKey(c.getWorld().getUID(), c.getX(), c.getZ()); }

    @Override public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof ChunkKey k)) return false;
        return x == k.x && z == k.z && Objects.equals(world, k.world);
    }
    @Override public int hashCode() { return Objects.hash(world, x, z); }
    @Override public String toString() { return world + ":" + x + ":" + z; }
}
