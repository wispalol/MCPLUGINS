# OPMGriefGuardLite

Chunk claims + trust/untrust.

Build: mvn clean package
