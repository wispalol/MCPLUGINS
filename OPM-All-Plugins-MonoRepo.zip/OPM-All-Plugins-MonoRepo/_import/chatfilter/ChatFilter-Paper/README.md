# ChatFilter (Paper) – 1.21.x (incl. 1.21.11)

This is a **Paper plugin** that filters chat and can **block messages so they do NOT appear in chat**.

## Requirements
- Paper 1.21.x (works across patch updates)
- Java 21

## Build
```bash
mvn clean package
```

Jar output: `target/ChatFilter-2.0.0.jar`

## Install
Drop jar into `plugins/` and restart.

## Commands
- `/chatfilter reload`
- `/chatfilter status`

## Permissions
- `chatfilter.bypass`
- `chatfilter.reload`
- `chatfilter.notify`
