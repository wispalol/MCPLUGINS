package uk.chatfilter;

import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;

public final class ChatFilterCommand implements CommandExecutor {
    private final ChatFilterPlugin plugin;

    public ChatFilterCommand(ChatFilterPlugin plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (args.length == 0) {
            sender.sendMessage("§e/chatfilter reload §7or §e/chatfilter status");
            return true;
        }
        if ("reload".equalsIgnoreCase(args[0])) {
            if (!sender.hasPermission("chatfilter.reload")) return true;
            plugin.reloadAll();
            sender.sendMessage("§aChatFilter reloaded.");
            return true;
        }
        if ("status".equalsIgnoreCase(args[0])) {
            ChatFilterConfig c = plugin.cfg();
            sender.sendMessage("§eChatFilter §7v2.0.0");
            sender.sendMessage("§7Enabled: §f" + c.enabled + "  §7Mode: §f" + c.mode + "  §7AntiBypass: §f" + c.antiBypass);
            sender.sendMessage("§7Words: §f" + c.blockedWords.size() + "  §7Regex: §f" + c.regexFilters.size());
            sender.sendMessage("§7Violations: §f" + c.violationsEnabled + "  §7MuteAt: §f" + c.muteAt + " (§f" + c.muteSeconds + "s§7)");
            return true;
        }
        return true;
    }
}
