package uk.chatfilter;

import org.bukkit.Bukkit;
import org.bukkit.entity.Player;

public final class StaffNotifier {
    private StaffNotifier() {}

    public static void notify(ChatFilterPlugin plugin, Player sender, String original, String rule) {
        ChatFilterConfig cfg = plugin.cfg();
        String msg = cfg.staffAlert
                .replace("{player}", sender.getName())
                .replace("{rule}", rule == null ? "" : rule);

        if (cfg.staffIncludeOriginal) {
            msg = msg + " §7msg: §f" + original;
        }

        for (Player p : Bukkit.getOnlinePlayers()) {
            if (p.hasPermission("chatfilter.notify")) {
                p.sendMessage(msg);
            }
        }
    }
}
