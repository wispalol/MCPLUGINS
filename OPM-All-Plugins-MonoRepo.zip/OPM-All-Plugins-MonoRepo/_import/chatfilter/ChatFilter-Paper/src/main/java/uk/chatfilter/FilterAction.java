package uk.chatfilter;

public enum FilterAction {
    WARN,
    BLOCK,
    MUTE
}
