package uk.chatfilter;

import io.papermc.paper.event.player.AsyncChatEvent;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.serializer.plain.PlainTextComponentSerializer;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;

public final class ChatListener implements Listener {
    private static final PlainTextComponentSerializer PLAIN = PlainTextComponentSerializer.plainText();
    private final ChatFilterPlugin plugin;

    public ChatListener(ChatFilterPlugin plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onChat(AsyncChatEvent event) {
        ChatFilterConfig cfg = plugin.cfg();
        if (!cfg.enabled) return;

        Player p = event.getPlayer();
        if (p.hasPermission("chatfilter.bypass")) return;

        if (plugin.tracker().isMuted(p)) {
            // cancel so it never appears
            event.setCancelled(true);
            if (cfg.sendChatWarning) p.sendMessage(cfg.mutedMessage);
            return;
        }

        String raw = PLAIN.serialize(event.message());
        FilterResult result = plugin.engine().evaluate(raw);

        if (!result.hit) return;

        int strikes = plugin.tracker().addStrike(p);
        FilterAction action = plugin.engine().decideAction(strikes);

        // player feedback
        if (cfg.sendChatWarning) p.sendMessage(cfg.playerWarning);
        if (cfg.sendActionbar) p.sendActionBar(Component.text(cfg.actionbarWarning));

        // staff notify
        if (cfg.staffNotify) {
            StaffNotifier.notify(plugin, p, raw, result.matchedRule);
        }

        if (action == FilterAction.MUTE) {
            plugin.tracker().mute(p);
            event.setCancelled(true);
            p.sendMessage(cfg.mutedMessage);
            return;
        }

        // WARN mode: allow message through (but we already warned)
        if (action == FilterAction.WARN && "WARN".equalsIgnoreCase(cfg.mode)) return;

        // CENSOR mode: replace message and allow
        if ("CENSOR".equalsIgnoreCase(cfg.mode)) {
            String censored = plugin.engine().censor(raw, result);
            event.message(Component.text(censored));
            return;
        }

        // BLOCK: cancel so it does NOT show in chat
        event.setCancelled(true);
    }
}
