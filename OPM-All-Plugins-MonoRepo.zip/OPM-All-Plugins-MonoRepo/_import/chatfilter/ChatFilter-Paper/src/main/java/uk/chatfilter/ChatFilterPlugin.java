package uk.chatfilter;

import org.bukkit.plugin.java.JavaPlugin;

public final class ChatFilterPlugin extends JavaPlugin {

    private ChatFilterConfig cfg;
    private FilterEngine engine;
    private ViolationTracker tracker;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        reloadAll();

        getServer().getPluginManager().registerEvents(new ChatListener(this), this);
        getCommand("chatfilter").setExecutor(new ChatFilterCommand(this));
        getLogger().info("ChatFilter enabled.");
    }

    public void reloadAll() {
        reloadConfig();
        this.cfg = new ChatFilterConfig(this);
        this.engine = new FilterEngine(cfg);
        this.tracker = new ViolationTracker(cfg);
    }

    public ChatFilterConfig cfg() { return cfg; }
    public FilterEngine engine() { return engine; }
    public ViolationTracker tracker() { return tracker; }
}
