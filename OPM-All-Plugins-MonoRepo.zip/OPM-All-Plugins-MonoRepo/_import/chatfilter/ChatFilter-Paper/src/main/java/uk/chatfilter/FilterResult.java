package uk.chatfilter;

public final class FilterResult {
    public final boolean hit;
    public final String matchedRule;

    private FilterResult(boolean hit, String matchedRule) {
        this.hit = hit;
        this.matchedRule = matchedRule == null ? "" : matchedRule;
    }

    public static FilterResult clean() { return new FilterResult(false, ""); }
    public static FilterResult hit(String rule) { return new FilterResult(true, rule); }
}
