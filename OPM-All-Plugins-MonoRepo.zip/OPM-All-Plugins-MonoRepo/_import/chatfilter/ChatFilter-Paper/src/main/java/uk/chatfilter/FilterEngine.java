package uk.chatfilter;

import uk.chatfilter.util.MessageNormalizer;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;

public final class FilterEngine {
    private final ChatFilterConfig cfg;
    private final MessageNormalizer normalizer;
    private final List<String> words;
    private final List<Pattern> regex;

    public FilterEngine(ChatFilterConfig cfg) {
        this.cfg = cfg;
        this.normalizer = new MessageNormalizer(cfg.antiBypass);

        this.words = new ArrayList<>();
        for (String w : cfg.blockedWords) {
            if (w == null) continue;
            String t = w.trim().toLowerCase();
            if (!t.isEmpty()) words.add(t);
        }

        this.regex = new ArrayList<>();
        for (String r : cfg.regexFilters) {
            if (r == null) continue;
            String t = r.trim();
            if (t.isEmpty()) continue;
            try { regex.add(Pattern.compile(t)); } catch (Exception ignored) {}
        }
    }

    public FilterResult evaluate(String rawMessage) {
        if (rawMessage == null || rawMessage.isEmpty()) return FilterResult.clean();
        String normalized = normalizer.normalize(rawMessage);

        for (String w : words) {
            if (normalized.contains(w)) return FilterResult.hit("word:" + w);
        }

        for (Pattern p : regex) {
            if (p.matcher(rawMessage).find() || p.matcher(normalized).find()) {
                return FilterResult.hit("regex:" + p.pattern());
            }
        }
        return FilterResult.clean();
    }

    public FilterAction decideAction(int strikes) {
        if (!cfg.violationsEnabled) {
            return "WARN".equalsIgnoreCase(cfg.mode) ? FilterAction.WARN : FilterAction.BLOCK;
        }
        if (strikes >= cfg.muteAt) return FilterAction.MUTE;
        if (strikes >= cfg.blockAt) return FilterAction.BLOCK;
        if (strikes >= cfg.warnAt) return FilterAction.WARN;
        return FilterAction.WARN;
    }

    public String censor(String raw, FilterResult result) {
        // Simple censor: replace any matched blocked word occurrences (non-normalized)
        String out = raw;
        for (String w : words) {
            out = out.replaceAll("(?i)" + Pattern.quote(w), cfg.censorChar.repeat(Math.max(1, w.length())));
        }
        return out;
    }
}
