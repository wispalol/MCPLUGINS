package uk.chatfilter;

import org.bukkit.entity.Player;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

public final class ViolationTracker {
    private final ChatFilterConfig cfg;
    private final Map<UUID, Integer> strikes = new ConcurrentHashMap<>();
    private final Map<UUID, Long> mutedUntilMs = new ConcurrentHashMap<>();

    public ViolationTracker(ChatFilterConfig cfg) {
        this.cfg = cfg;
    }

    public int addStrike(Player player) {
        if (!cfg.violationsEnabled) return 0;
        UUID id = player.getUniqueId();
        int next = strikes.getOrDefault(id, 0) + 1;
        strikes.put(id, next);
        return next;
    }

    public boolean isMuted(Player player) {
        Long until = mutedUntilMs.get(player.getUniqueId());
        if (until == null) return false;
        if (System.currentTimeMillis() >= until) {
            mutedUntilMs.remove(player.getUniqueId());
            return false;
        }
        return true;
    }

    public void mute(Player player) {
        if (!cfg.violationsEnabled) return;
        long until = System.currentTimeMillis() + (cfg.muteSeconds * 1000L);
        mutedUntilMs.put(player.getUniqueId(), until);
    }

    public int getStrikes(Player player) {
        return strikes.getOrDefault(player.getUniqueId(), 0);
    }
}
