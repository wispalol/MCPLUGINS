package uk.chatfilter;

import org.bukkit.ChatColor;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.List;

public final class ChatFilterConfig {
    public final boolean enabled;
    public final String mode; // BLOCK | CENSOR | WARN
    public final boolean antiBypass;

    public final List<String> blockedWords;
    public final List<String> regexFilters;
    public final String censorChar;

    public final boolean staffNotify;
    public final boolean staffIncludeOriginal;
    public final String staffAlert;

    public final boolean sendActionbar;
    public final boolean sendChatWarning;
    public final String playerWarning;
    public final String actionbarWarning;

    public final boolean violationsEnabled;
    public final int warnAt, blockAt, muteAt, muteSeconds;
    public final String mutedMessage;

    public ChatFilterConfig(JavaPlugin plugin) {
        FileConfiguration c = plugin.getConfig();
        enabled = c.getBoolean("enabled", true);
        mode = c.getString("mode", "BLOCK").toUpperCase();
        antiBypass = c.getBoolean("anti-bypass", true);

        blockedWords = c.getStringList("blocked-words");
        regexFilters = c.getStringList("regex-filters");
        censorChar = c.getString("censor-character", "*");

        sendActionbar = c.getBoolean("feedback.send-actionbar", true);
        sendChatWarning = c.getBoolean("feedback.send-chat-warning", true);
        playerWarning = color(c.getString("feedback.player-warning", "&cPlease keep chat appropriate."));
        actionbarWarning = color(c.getString("feedback.actionbar-warning", "&c⚠ Inappropriate language blocked"));

        staffNotify = c.getBoolean("staff.notify", true);
        staffIncludeOriginal = c.getBoolean("staff.include-original", true);
        staffAlert = color(c.getString("staff.alert", "&e[ChatFilter] &6{player} &etried blocked chat. &7(rule: {rule})"));

        violationsEnabled = c.getBoolean("violations.enabled", true);
        warnAt = c.getInt("violations.warn-at", 1);
        blockAt = c.getInt("violations.block-at", 2);
        muteAt = c.getInt("violations.mute-at", 4);
        muteSeconds = c.getInt("violations.mute-seconds", 300);
        mutedMessage = color(c.getString("violations.muted-message", "&cYou are muted for chat filter violations."));
    }

    private static String color(String s) {
        return ChatColor.translateAlternateColorCodes('&', s == null ? "" : s);
    }
}
