package uk.chatfilter.util;

import java.text.Normalizer;
import java.util.Map;

public final class MessageNormalizer {
    private final boolean enabled;

    private static final Map<Character, Character> LEET = Map.ofEntries(
            Map.entry('@', 'a'),
            Map.entry('0', 'o'),
            Map.entry('1', 'i'),
            Map.entry('!', 'i'),
            Map.entry('3', 'e'),
            Map.entry('4', 'a'),
            Map.entry('5', 's'),
            Map.entry('$', 's'),
            Map.entry('7', 't')
    );

    public MessageNormalizer(boolean enabled) {
        this.enabled = enabled;
    }

    public String normalize(String input) {
        if (input == null) return "";
        String s = input.toLowerCase();

        s = Normalizer.normalize(s, Normalizer.Form.NFKD);
        s = s.replaceAll("\\p{M}+", "");

        if (!enabled) return s;

        StringBuilder out = new StringBuilder(s.length());
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            c = LEET.getOrDefault(c, c);
            if (Character.isLetterOrDigit(c)) out.append(c);
        }
        return out.toString();
    }
}
