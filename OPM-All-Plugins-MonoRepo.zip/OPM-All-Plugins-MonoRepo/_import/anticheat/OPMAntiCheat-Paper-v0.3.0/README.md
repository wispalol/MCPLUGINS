# OPMAntiCheat (Paper + ProtocolLib) v0.3.0 – SMP focused

A stronger anti-cheat starter for **Paper 1.21.x** using **ProtocolLib** packet listeners,
tuned for **SMP** (strong but avoids instant false bans).

## Requirements
- Paper 1.21.x (incl. 1.21.11)
- Java 21
- ProtocolLib installed

## Build
```bash
mvn clean package
```

## Install
1. Install ProtocolLib
2. Put `OPMAntiCheat-0.3.0.jar` in `plugins/`
3. Restart
4. Configure `plugins/OPMAntiCheat/config.yml`

## Checks (v0.3.0)
- SpeedA (movement)
- FlyA (air-time)
- TimerA (too many move packets/sec)
- ReachA (attack reach)
- AutoClickerA (attack rate)
- NoSlowA (full speed while eating/blocking/bow)
- FastPlaceA (block placement too fast)
- VelocityA (ignoring knockback)

## Bans
This version supports **ban commands** per check when the check hits its `ban-threshold` VL.
Tune thresholds for your server to avoid false bans from lag or special mechanics.
