package uk.opm.anticheat;

import com.comphenix.protocol.ProtocolLibrary;
import com.comphenix.protocol.ProtocolManager;
import org.bukkit.Bukkit;
import org.bukkit.command.PluginCommand;
import org.bukkit.plugin.java.JavaPlugin;
import uk.opm.anticheat.commands.AntiCheatCommand;
import uk.opm.anticheat.data.PlayerDataStore;
import uk.opm.anticheat.util.AlertService;

public final class OPMAntiCheatPlugin extends JavaPlugin {

    private ProtocolManager protocol;
    private PlayerDataStore dataStore;
    private AlertService alerts;
    private CheckManager checks;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        if (!getConfig().getBoolean("enabled", true)) {
            getLogger().warning("OPMAntiCheat disabled via config.");
            return;
        }

        protocol = ProtocolLibrary.getProtocolManager();
        dataStore = new PlayerDataStore(this);
        alerts = new AlertService(this);
        checks = new CheckManager(this);

        checks.registerAll(protocol, dataStore, alerts);
        dataStore.startDecayTask();

        PluginCommand cmd = getCommand("anticheat");
        if (cmd != null) cmd.setExecutor(new AntiCheatCommand(this));

        Bukkit.getLogger().info("[OPMAntiCheat] Enabled v0.3.0");
    }

    @Override
    public void onDisable() {
        if (checks != null) checks.unregisterAll();
    }

    public PlayerDataStore dataStore() { return dataStore; }
    public AlertService alerts() { return alerts; }
}
