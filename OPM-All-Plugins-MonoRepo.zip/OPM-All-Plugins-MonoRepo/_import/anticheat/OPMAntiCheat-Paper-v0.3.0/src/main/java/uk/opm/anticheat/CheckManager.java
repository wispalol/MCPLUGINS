package uk.opm.anticheat;

import com.comphenix.protocol.ProtocolManager;
import uk.opm.anticheat.checks.*;
import uk.opm.anticheat.data.PlayerDataStore;
import uk.opm.anticheat.util.AlertService;

import java.util.ArrayList;
import java.util.List;

public final class CheckManager {
    private final OPMAntiCheatPlugin plugin;
    private final List<AutoCloseable> registered = new ArrayList<>();

    public CheckManager(OPMAntiCheatPlugin plugin) {
        this.plugin = plugin;
    }

    public void registerAll(ProtocolManager protocol, PlayerDataStore data, AlertService alerts) {
        registered.add(new SpeedA(plugin, protocol, data, alerts));
        registered.add(new FlyA(plugin, protocol, data, alerts));
        registered.add(new TimerA(plugin, protocol, data, alerts));
        registered.add(new ReachA(plugin, protocol, data, alerts));
        registered.add(new AutoClickerA(plugin, protocol, data, alerts));

        registered.add(new NoSlowA(plugin, protocol, data, alerts));
        registered.add(new FastPlaceA(plugin, protocol, data, alerts));
        registered.add(new VelocityA(plugin, protocol, data, alerts));
    }

    public void unregisterAll() {
        for (AutoCloseable c : registered) {
            try { c.close(); } catch (Exception ignored) {}
        }
        registered.clear();
    }
}
