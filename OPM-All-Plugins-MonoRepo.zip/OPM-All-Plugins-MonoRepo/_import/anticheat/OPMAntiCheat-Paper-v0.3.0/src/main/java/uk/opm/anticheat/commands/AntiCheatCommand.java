package uk.opm.anticheat.commands;

import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.metadata.FixedMetadataValue;
import uk.opm.anticheat.OPMAntiCheatPlugin;
import uk.opm.anticheat.data.PlayerState;

public final class AntiCheatCommand implements CommandExecutor {
    private final OPMAntiCheatPlugin plugin;

    public AntiCheatCommand(OPMAntiCheatPlugin plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (args.length == 0) {
            sender.sendMessage("§e/anticheat reload §7| §e/anticheat alerts §7| §e/anticheat status <player>");
            return true;
        }

        if ("reload".equalsIgnoreCase(args[0])) {
            if (!sender.hasPermission("opmac.reload")) return true;
            plugin.reloadConfig();
            sender.sendMessage("§aOPMAntiCheat reloaded.");
            return true;
        }

        if ("alerts".equalsIgnoreCase(args[0])) {
            if (!(sender instanceof Player p)) {
                sender.sendMessage("Console always receives alerts.");
                return true;
            }
            if (!p.hasPermission("opmac.alerts")) return true;

            boolean wants = plugin.alerts().playerWantsAlerts(p);
            if (wants) {
                p.setMetadata("opmac_alerts_off", new FixedMetadataValue(plugin, true));
                p.sendMessage("§cAntiCheat alerts OFF");
            } else {
                p.removeMetadata("opmac_alerts_off", plugin);
                p.sendMessage("§aAntiCheat alerts ON");
            }
            return true;
        }

        if ("status".equalsIgnoreCase(args[0])) {
            if (!sender.hasPermission("opmac.status")) return true;
            if (args.length < 2) {
                sender.sendMessage("§cUsage: /anticheat status <player>");
                return true;
            }
            Player t = plugin.getServer().getPlayerExact(args[1]);
            if (t == null) {
                sender.sendMessage("§cPlayer not found.");
                return true;
            }
            PlayerState s = plugin.dataStore().get(t);
            sender.sendMessage("§eOPMAntiCheat status for §f" + t.getName());
            sender.sendMessage("§7VL Speed: §f" + String.format("%.2f", s.getVl(uk.opm.anticheat.CheckType.SPEED)));
            sender.sendMessage("§7VL Fly: §f" + String.format("%.2f", s.getVl(uk.opm.anticheat.CheckType.FLY)));
            sender.sendMessage("§7VL Timer: §f" + String.format("%.2f", s.getVl(uk.opm.anticheat.CheckType.TIMER)));
            sender.sendMessage("§7VL Reach: §f" + String.format("%.2f", s.getVl(uk.opm.anticheat.CheckType.REACH)));
            sender.sendMessage("§7VL AutoClicker: §f" + String.format("%.2f", s.getVl(uk.opm.anticheat.CheckType.AUTOCLICKER)));
            sender.sendMessage("§7VL NoSlow: §f" + String.format("%.2f", s.getVl(uk.opm.anticheat.CheckType.NOSLOW)));
            sender.sendMessage("§7VL FastPlace: §f" + String.format("%.2f", s.getVl(uk.opm.anticheat.CheckType.FASTPLACE)));
            sender.sendMessage("§7VL Velocity: §f" + String.format("%.2f", s.getVl(uk.opm.anticheat.CheckType.VELOCITY)));
            sender.sendMessage("§7AirTicks: §f" + s.airTicks + "  §7AttacksWindow: §f" + s.attackTimes.size());
            return true;
        }

        return true;
    }
}
