package uk.opm.anticheat.util;

import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;

public final class Punish {
    private Punish() {}

    public static void maybeBan(JavaPlugin plugin, Player player, String checkName, double vl, double threshold) {
        if (!plugin.getConfig().getBoolean("punishments.enabled", true)) return;
        if (vl < threshold) return;

        for (String cmd : plugin.getConfig().getStringList("punishments.ban-commands")) {
            Bukkit.dispatchCommand(
                    Bukkit.getConsoleSender(),
                    cmd.replace("{player}", player.getName()).replace("{check}", checkName)
            );
        }
    }
}
