package uk.opm.anticheat.data;

import org.bukkit.Location;
import uk.opm.anticheat.CheckType;

import java.util.ArrayDeque;
import java.util.Deque;
import java.util.EnumMap;
import java.util.Map;

public final class PlayerState {

    public Location lastGroundLocation = null;

    // movement tracking
    public long lastMoveTimeMs = 0L;
    public double lastX = Double.NaN;
    public double lastZ = Double.NaN;

    public int airTicks = 0;

    // per-check VL
    public final Map<CheckType, Double> vl = new EnumMap<>(CheckType.class);

    // AutoClicker: attack timestamps (ms)
    public final Deque<Long> attackTimes = new ArrayDeque<>();

    // TimerA: movement packet timestamps (ms)
    public final Deque<Long> movePacketTimes = new ArrayDeque<>();

    // FastPlaceA: placement timestamps (ms)
    public final Deque<Long> placeTimes = new ArrayDeque<>();

    // VelocityA: expected knockback
    public long lastVelocityMs = 0L;
    public double expectedVelXZ = 0.0; // horizontal speed expectation

    public double getVl(CheckType type) { return vl.getOrDefault(type, 0.0); }

    public double addVl(CheckType type, double add) {
        double next = getVl(type) + add;
        vl.put(type, next);
        return next;
    }

    public void decayAll(double amount) {
        if (amount <= 0) return;
        for (CheckType t : CheckType.values()) {
            double cur = getVl(t);
            if (cur <= 0) continue;
            vl.put(t, Math.max(0.0, cur - amount));
        }
    }
}
