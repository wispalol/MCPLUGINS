package uk.opm.anticheat.checks;

import com.comphenix.protocol.PacketType;
import com.comphenix.protocol.ProtocolManager;
import com.comphenix.protocol.events.PacketAdapter;
import com.comphenix.protocol.events.PacketContainer;
import com.comphenix.protocol.events.PacketEvent;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import uk.opm.anticheat.CheckType;
import uk.opm.anticheat.OPMAntiCheatPlugin;
import uk.opm.anticheat.data.PlayerDataStore;
import uk.opm.anticheat.data.PlayerState;
import uk.opm.anticheat.util.AlertService;
import uk.opm.anticheat.util.Punish;

public final class ReachA implements AutoCloseable {
    private final OPMAntiCheatPlugin plugin;
    private final ProtocolManager protocol;
    private final PlayerDataStore data;
    private final AlertService alerts;
    private final PacketAdapter adapter;

    public ReachA(OPMAntiCheatPlugin plugin, ProtocolManager protocol, PlayerDataStore data, AlertService alerts) {
        this.plugin = plugin;
        this.protocol = protocol;
        this.data = data;
        this.alerts = alerts;

        adapter = new PacketAdapter(plugin, PacketType.Play.Client.USE_ENTITY) {
            @Override
            public void onPacketReceiving(PacketEvent event) {
                if (!plugin.getConfig().getBoolean("checks.reach.enabled", true)) return;

                Player p = event.getPlayer();
                if (p == null || !p.isOnline()) return;
                if (p.hasPermission("opmac.bypass")) return;
                if (p.getGameMode() == GameMode.CREATIVE || p.getGameMode() == GameMode.SPECTATOR) return;

                PacketContainer packet = event.getPacket();
                Integer entityId = packet.getIntegers().read(0);

                Entity target = null;
                for (Entity e : p.getWorld().getEntities()) {
                    if (e.getEntityId() == entityId) { target = e; break; }
                }
                if (target == null) return;

                var actions = packet.getEnumEntityUseActions();
                if (actions == null || actions.size() == 0) return;
                Object action = actions.read(0);
                if (action == null || !action.toString().toUpperCase().contains("ATTACK")) return;

                Location eye = p.getEyeLocation();
                Location t = target.getLocation().add(0, target.getHeight() * 0.5, 0);
                double dist = eye.distance(t);

                double max = plugin.getConfig().getDouble("checks.reach.max-reach", 3.25);
                double pingExtra = plugin.getConfig().getDouble("checks.reach.extra-for-high-ping", 0.35);
                int ping = p.getPing();
                if (ping > 150) max += pingExtra;

                max += 0.25;

                if (dist > max) {
                    PlayerState s = data.get(p);
                    double add = plugin.getConfig().getDouble("checks.reach.vl-per-flag", 1.2);
                    double vl = s.addVl(CheckType.REACH, add);
                    alerts.alert("ReachA", p, String.format("dist=%.2f max=%.2f ping=%d", dist, max, ping), vl);

                    double banTh = plugin.getConfig().getDouble("checks.reach.ban-threshold", 12.0);
                    Punish.maybeBan(plugin, p, "ReachA", vl, banTh);
                }
            }
        };

        protocol.addPacketListener(adapter);
    }

    @Override
    public void close() { protocol.removePacketListener(adapter); }
}
