package uk.opm.anticheat.checks;

import com.comphenix.protocol.ProtocolManager;
import com.comphenix.protocol.PacketType;
import com.comphenix.protocol.events.PacketAdapter;
import com.comphenix.protocol.events.PacketContainer;
import com.comphenix.protocol.events.PacketEvent;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.entity.Player;
import uk.opm.anticheat.CheckType;
import uk.opm.anticheat.OPMAntiCheatPlugin;
import uk.opm.anticheat.data.PlayerDataStore;
import uk.opm.anticheat.data.PlayerState;
import uk.opm.anticheat.util.AlertService;
import uk.opm.anticheat.util.MovementUtil;
import uk.opm.anticheat.util.Punish;

public final class SpeedA implements AutoCloseable {
    private final OPMAntiCheatPlugin plugin;
    private final ProtocolManager protocol;
    private final PlayerDataStore data;
    private final AlertService alerts;
    private final PacketAdapter adapter;

    public SpeedA(OPMAntiCheatPlugin plugin, ProtocolManager protocol, PlayerDataStore data, AlertService alerts) {
        this.plugin = plugin;
        this.protocol = protocol;
        this.data = data;
        this.alerts = alerts;

        adapter = new PacketAdapter(plugin, PacketType.Play.Client.POSITION, PacketType.Play.Client.POSITION_LOOK) {
            @Override
            public void onPacketReceiving(PacketEvent event) {
                if (!plugin.getConfig().getBoolean("checks.speed.enabled", true)) return;

                Player p = event.getPlayer();
                if (p == null || !p.isOnline()) return;
                if (p.hasPermission("opmac.bypass")) return;
                if (p.getGameMode() == GameMode.CREATIVE || p.getGameMode() == GameMode.SPECTATOR) return;
                if (p.isFlying() || p.isGliding() || p.isInsideVehicle()) return;

                PacketContainer packet = event.getPacket();
                double x = packet.getDoubles().read(0);
                double z = packet.getDoubles().read(2);

                PlayerState s = data.get(p);
                long now = System.currentTimeMillis();

                double bps = MovementUtil.horizontalBps(s, x, z, now);
                if (bps <= 0.0) return;

                double max = plugin.getConfig().getDouble("checks.speed.max-horizontal-bps", 7.2);
                double tol = plugin.getConfig().getDouble("checks.speed.tolerance-bps", 0.9);

                if (p.isSprinting()) max += 0.4;
                if (p.getWalkSpeed() > 0.2f) max += 1.0;

                if (bps > (max + tol)) {
                    double add = plugin.getConfig().getDouble("checks.speed.vl-per-flag", 1.2);
                    double vl = s.addVl(CheckType.SPEED, add);

                    alerts.alert("SpeedA", p, String.format("bps=%.2f", bps), vl);

                    if (plugin.getConfig().getBoolean("punishments.setback-enabled", true) && s.lastGroundLocation != null) {
                        Location back = s.lastGroundLocation.clone();
                        plugin.getServer().getScheduler().runTask(plugin, () -> p.teleport(back));
                    }

                    double banTh = plugin.getConfig().getDouble("checks.speed.ban-threshold", 8.0);
                    Punish.maybeBan(plugin, p, "SpeedA", vl, banTh);
                }

                if (p.isOnGround()) s.lastGroundLocation = p.getLocation();
            }
        };

        protocol.addPacketListener(adapter);
    }

    @Override
    public void close() { protocol.removePacketListener(adapter); }
}
