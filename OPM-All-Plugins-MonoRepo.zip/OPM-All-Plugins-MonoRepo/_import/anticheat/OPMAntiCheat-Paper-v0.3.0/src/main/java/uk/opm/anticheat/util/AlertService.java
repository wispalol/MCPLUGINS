package uk.opm.anticheat.util;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.metadata.MetadataValue;
import org.bukkit.plugin.java.JavaPlugin;

public final class AlertService {
    private static final LegacyComponentSerializer LEGACY = LegacyComponentSerializer.legacyAmpersand();
    private final JavaPlugin plugin;

    public AlertService(JavaPlugin plugin) {
        this.plugin = plugin;
    }

    public boolean playerWantsAlerts(Player p) {
        for (MetadataValue v : p.getMetadata("opmac_alerts_off")) {
            if (v.asBoolean()) return false;
        }
        return true;
    }

    public void alert(String checkName, Player player, String detail, double vl) {
        if (!plugin.getConfig().getBoolean("alerts.enabled", true)) return;

        String perm = plugin.getConfig().getString("alerts.notify-permission", "opmac.alerts");
        String prefix = plugin.getConfig().getString("alerts.prefix", "&6[AC]&r ");
        String msg = prefix + "&e" + player.getName() + " &7flagged &f" + checkName
                + " &7(" + detail + ") &8VL:&f " + String.format("%.2f", vl);

        Component c = LEGACY.deserialize(msg);
        for (Player p : Bukkit.getOnlinePlayers()) {
            if (p.hasPermission(perm) && playerWantsAlerts(p)) p.sendMessage(c);
        }
        Bukkit.getConsoleSender().sendMessage(LEGACY.deserialize(msg));
    }
}
