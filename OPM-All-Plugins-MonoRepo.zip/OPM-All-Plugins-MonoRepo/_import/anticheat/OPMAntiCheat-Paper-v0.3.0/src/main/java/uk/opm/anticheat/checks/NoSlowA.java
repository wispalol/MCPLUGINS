package uk.opm.anticheat.checks;

import com.comphenix.protocol.ProtocolManager;
import com.comphenix.protocol.PacketType;
import com.comphenix.protocol.events.PacketAdapter;
import com.comphenix.protocol.events.PacketContainer;
import com.comphenix.protocol.events.PacketEvent;
import org.bukkit.GameMode;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import uk.opm.anticheat.CheckType;
import uk.opm.anticheat.OPMAntiCheatPlugin;
import uk.opm.anticheat.data.PlayerDataStore;
import uk.opm.anticheat.data.PlayerState;
import uk.opm.anticheat.util.AlertService;
import uk.opm.anticheat.util.MovementUtil;
import uk.opm.anticheat.util.Punish;

public final class NoSlowA implements AutoCloseable {
    private final OPMAntiCheatPlugin plugin;
    private final ProtocolManager protocol;
    private final PlayerDataStore data;
    private final AlertService alerts;
    private final PacketAdapter adapter;

    public NoSlowA(OPMAntiCheatPlugin plugin, ProtocolManager protocol, PlayerDataStore data, AlertService alerts) {
        this.plugin = plugin;
        this.protocol = protocol;
        this.data = data;
        this.alerts = alerts;

        adapter = new PacketAdapter(plugin, PacketType.Play.Client.POSITION, PacketType.Play.Client.POSITION_LOOK) {
            @Override
            public void onPacketReceiving(PacketEvent event) {
                if (!plugin.getConfig().getBoolean("checks.noslow.enabled", true)) return;

                Player p = event.getPlayer();
                if (p == null || !p.isOnline()) return;
                if (p.hasPermission("opmac.bypass")) return;
                if (p.getGameMode() == GameMode.CREATIVE || p.getGameMode() == GameMode.SPECTATOR) return;
                if (p.isFlying() || p.isGliding() || p.isInsideVehicle()) return;

                // Only check while using item / blocking / bow draw
                boolean using = p.isHandRaised() || p.isBlocking();
                if (!using) return;

                // ignore in liquids / ladders / webs (SMP safe)
                Material feet = p.getLocation().getBlock().getType();
                if (feet == Material.WATER || feet == Material.LAVA || feet == Material.BUBBLE_COLUMN) return;
                if (feet == Material.LADDER || feet == Material.VINE || feet == Material.SCAFFOLDING || feet == Material.COBWEB) return;

                PacketContainer packet = event.getPacket();
                double x = packet.getDoubles().read(0);
                double z = packet.getDoubles().read(2);

                PlayerState s = data.get(p);
                long now = System.currentTimeMillis();
                double bps = MovementUtil.horizontalBps(s, x, z, now);
                if (bps <= 0.0) return;

                double max = plugin.getConfig().getDouble("checks.noslow.max-bps-while-using", 3.4);
                double tol = plugin.getConfig().getDouble("checks.noslow.tolerance-bps", 0.6);

                if (bps > (max + tol)) {
                    double add = plugin.getConfig().getDouble("checks.noslow.vl-per-flag", 1.0);
                    double vl = s.addVl(CheckType.NOSLOW, add);
                    alerts.alert("NoSlowA", p, String.format("bps=%.2f", bps), vl);

                    double banTh = plugin.getConfig().getDouble("checks.noslow.ban-threshold", 10.0);
                    Punish.maybeBan(plugin, p, "NoSlowA", vl, banTh);
                }
            }
        };

        protocol.addPacketListener(adapter);
    }

    @Override
    public void close() { protocol.removePacketListener(adapter); }
}
