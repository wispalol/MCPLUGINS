package uk.opm.anticheat.checks;

import com.comphenix.protocol.PacketType;
import com.comphenix.protocol.ProtocolManager;
import com.comphenix.protocol.events.PacketAdapter;
import com.comphenix.protocol.events.PacketContainer;
import com.comphenix.protocol.events.PacketEvent;
import org.bukkit.GameMode;
import org.bukkit.entity.Player;
import uk.opm.anticheat.CheckType;
import uk.opm.anticheat.OPMAntiCheatPlugin;
import uk.opm.anticheat.data.PlayerDataStore;
import uk.opm.anticheat.data.PlayerState;
import uk.opm.anticheat.util.AlertService;
import uk.opm.anticheat.util.Punish;

public final class AutoClickerA implements AutoCloseable {
    private final OPMAntiCheatPlugin plugin;
    private final ProtocolManager protocol;
    private final PlayerDataStore data;
    private final AlertService alerts;
    private final PacketAdapter adapter;

    public AutoClickerA(OPMAntiCheatPlugin plugin, ProtocolManager protocol, PlayerDataStore data, AlertService alerts) {
        this.plugin = plugin;
        this.protocol = protocol;
        this.data = data;
        this.alerts = alerts;

        adapter = new PacketAdapter(plugin, PacketType.Play.Client.USE_ENTITY) {
            @Override
            public void onPacketReceiving(PacketEvent event) {
                if (!plugin.getConfig().getBoolean("checks.autoclicker.enabled", true)) return;

                Player p = event.getPlayer();
                if (p == null || !p.isOnline()) return;
                if (p.hasPermission("opmac.bypass")) return;
                if (p.getGameMode() == GameMode.CREATIVE || p.getGameMode() == GameMode.SPECTATOR) return;

                PacketContainer packet = event.getPacket();
                var actions = packet.getEnumEntityUseActions();
                if (actions == null || actions.size() == 0) return;
                Object action = actions.read(0);
                if (action == null || !action.toString().toUpperCase().contains("ATTACK")) return;

                PlayerState s = data.get(p);
                long now = System.currentTimeMillis();

                long window = plugin.getConfig().getLong("checks.autoclicker.window-ms", 1000);
                int maxCps = plugin.getConfig().getInt("checks.autoclicker.max-cps", 18);
                int minSamples = plugin.getConfig().getInt("checks.autoclicker.min-samples", 12);

                s.attackTimes.addLast(now);
                while (!s.attackTimes.isEmpty() && (now - s.attackTimes.peekFirst()) > window) {
                    s.attackTimes.removeFirst();
                }

                int cps = s.attackTimes.size();
                if (cps >= minSamples && cps > maxCps) {
                    double add = plugin.getConfig().getDouble("checks.autoclicker.vl-per-flag", 1.0);
                    double vl = s.addVl(CheckType.AUTOCLICKER, add);
                    alerts.alert("AutoClickerA", p, "cps=" + cps, vl);

                    double banTh = plugin.getConfig().getDouble("checks.autoclicker.ban-threshold", 15.0);
                    Punish.maybeBan(plugin, p, "AutoClickerA", vl, banTh);

                    s.attackTimes.clear();
                }
            }
        };

        protocol.addPacketListener(adapter);
    }

    @Override
    public void close() { protocol.removePacketListener(adapter); }
}
