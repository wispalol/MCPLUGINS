package uk.opm.anticheat.util;

import uk.opm.anticheat.data.PlayerState;

public final class MovementUtil {
    private MovementUtil() {}

    public static double horizontalBps(PlayerState s, double newX, double newZ, long nowMs) {
        if (Double.isNaN(s.lastX) || Double.isNaN(s.lastZ) || s.lastMoveTimeMs == 0L) {
            s.lastX = newX;
            s.lastZ = newZ;
            s.lastMoveTimeMs = nowMs;
            return 0.0;
        }
        long dt = nowMs - s.lastMoveTimeMs;
        if (dt <= 0) dt = 1;
        double dx = newX - s.lastX;
        double dz = newZ - s.lastZ;
        double dist = Math.sqrt(dx*dx + dz*dz);
        double bps = dist / (dt / 1000.0);

        s.lastX = newX;
        s.lastZ = newZ;
        s.lastMoveTimeMs = nowMs;
        return bps;
    }
}
