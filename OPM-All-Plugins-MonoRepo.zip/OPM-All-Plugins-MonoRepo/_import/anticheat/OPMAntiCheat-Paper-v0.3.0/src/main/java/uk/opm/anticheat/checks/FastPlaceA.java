package uk.opm.anticheat.checks;

import com.comphenix.protocol.ProtocolManager;
import com.comphenix.protocol.PacketType;
import com.comphenix.protocol.events.PacketAdapter;
import com.comphenix.protocol.events.PacketEvent;
import org.bukkit.GameMode;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import uk.opm.anticheat.CheckType;
import uk.opm.anticheat.OPMAntiCheatPlugin;
import uk.opm.anticheat.data.PlayerDataStore;
import uk.opm.anticheat.data.PlayerState;
import uk.opm.anticheat.util.AlertService;
import uk.opm.anticheat.util.Punish;

public final class FastPlaceA implements AutoCloseable {
    private final OPMAntiCheatPlugin plugin;
    private final ProtocolManager protocol;
    private final PlayerDataStore data;
    private final AlertService alerts;
    private final PacketAdapter adapter;

    public FastPlaceA(OPMAntiCheatPlugin plugin, ProtocolManager protocol, PlayerDataStore data, AlertService alerts) {
        this.plugin = plugin;
        this.protocol = protocol;
        this.data = data;
        this.alerts = alerts;

        adapter = new PacketAdapter(plugin,
                PacketType.Play.Client.BLOCK_PLACE,
                PacketType.Play.Client.USE_ITEM) {
            @Override
            public void onPacketReceiving(PacketEvent event) {
                if (!plugin.getConfig().getBoolean("checks.fastplace.enabled", true)) return;

                Player p = event.getPlayer();
                if (p == null || !p.isOnline()) return;
                if (p.hasPermission("opmac.bypass")) return;
                if (p.getGameMode() == GameMode.CREATIVE || p.getGameMode() == GameMode.SPECTATOR) return;

                ItemStack hand = p.getInventory().getItemInMainHand();
                if (hand == null || hand.getType() == Material.AIR) return;
                // only count when holding a block item
                if (!hand.getType().isBlock()) return;

                PlayerState s = data.get(p);
                long now = System.currentTimeMillis();

                long window = plugin.getConfig().getLong("checks.fastplace.window-ms", 1000);
                int maxPps = plugin.getConfig().getInt("checks.fastplace.max-places-per-second", 16);
                int minSamples = plugin.getConfig().getInt("checks.fastplace.min-samples", 10);

                s.placeTimes.addLast(now);
                while (!s.placeTimes.isEmpty() && (now - s.placeTimes.peekFirst()) > window) {
                    s.placeTimes.removeFirst();
                }

                int pps = s.placeTimes.size();
                if (pps >= minSamples && pps > maxPps) {
                    double add = plugin.getConfig().getDouble("checks.fastplace.vl-per-flag", 1.0);
                    double vl = s.addVl(CheckType.FASTPLACE, add);
                    alerts.alert("FastPlaceA", p, "pps=" + pps, vl);

                    double banTh = plugin.getConfig().getDouble("checks.fastplace.ban-threshold", 12.0);
                    Punish.maybeBan(plugin, p, "FastPlaceA", vl, banTh);

                    s.placeTimes.clear();
                }
            }
        };

        protocol.addPacketListener(adapter);
    }

    @Override
    public void close() { protocol.removePacketListener(adapter); }
}
