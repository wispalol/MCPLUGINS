package uk.opm.anticheat.checks;

import com.comphenix.protocol.ProtocolManager;
import com.comphenix.protocol.PacketType;
import com.comphenix.protocol.events.PacketAdapter;
import com.comphenix.protocol.events.PacketContainer;
import com.comphenix.protocol.events.PacketEvent;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.entity.Player;
import uk.opm.anticheat.CheckType;
import uk.opm.anticheat.OPMAntiCheatPlugin;
import uk.opm.anticheat.data.PlayerDataStore;
import uk.opm.anticheat.data.PlayerState;
import uk.opm.anticheat.util.AlertService;
import uk.opm.anticheat.util.MovementUtil;
import uk.opm.anticheat.util.Punish;

public final class VelocityA implements AutoCloseable {
    private final OPMAntiCheatPlugin plugin;
    private final ProtocolManager protocol;
    private final PlayerDataStore data;
    private final AlertService alerts;
    private final PacketAdapter sendAdapter;
    private final PacketAdapter moveAdapter;

    public VelocityA(OPMAntiCheatPlugin plugin, ProtocolManager protocol, PlayerDataStore data, AlertService alerts) {
        this.plugin = plugin;
        this.protocol = protocol;
        this.data = data;
        this.alerts = alerts;

        // Capture knockback packets sent to the player
        sendAdapter = new PacketAdapter(plugin, PacketType.Play.Server.ENTITY_VELOCITY) {
            @Override
            public void onPacketSending(PacketEvent event) {
                if (!plugin.getConfig().getBoolean("checks.velocity.enabled", true)) return;

                Player p = event.getPlayer();
                if (p == null || !p.isOnline()) return;
                if (p.hasPermission("opmac.bypass")) return;
                if (p.getGameMode() == GameMode.CREATIVE || p.getGameMode() == GameMode.SPECTATOR) return;

                PacketContainer packet = event.getPacket();
                int entityId = packet.getIntegers().read(0);
                if (entityId != p.getEntityId()) return;

                // Protocol velocity values are ints scaled by 8000
                double vx = packet.getIntegers().read(1) / 8000.0;
                double vz = packet.getIntegers().read(3) / 8000.0;

                double expected = Math.sqrt(vx*vx + vz*vz);
                double minExpected = plugin.getConfig().getDouble("checks.velocity.min-expected-horizontal", 0.20);
                if (expected < minExpected) return;

                PlayerState s = data.get(p);
                s.expectedVelXZ = expected;
                s.lastVelocityMs = System.currentTimeMillis();
            }
        };

        // On movement, see if player actually moved
        moveAdapter = new PacketAdapter(plugin, PacketType.Play.Client.POSITION, PacketType.Play.Client.POSITION_LOOK) {
            @Override
            public void onPacketReceiving(PacketEvent event) {
                if (!plugin.getConfig().getBoolean("checks.velocity.enabled", true)) return;

                Player p = event.getPlayer();
                if (p == null || !p.isOnline()) return;
                if (p.hasPermission("opmac.bypass")) return;
                if (p.getGameMode() == GameMode.CREATIVE || p.getGameMode() == GameMode.SPECTATOR) return;

                PlayerState s = data.get(p);
                if (s.lastVelocityMs == 0L || s.expectedVelXZ <= 0.0) return;

                long now = System.currentTimeMillis();
                long window = plugin.getConfig().getLong("checks.velocity.check-window-ms", 350);
                if (now - s.lastVelocityMs > window) {
                    s.lastVelocityMs = 0L;
                    s.expectedVelXZ = 0.0;
                    return;
                }

                PacketContainer packet = event.getPacket();
                double x = packet.getDoubles().read(0);
                double z = packet.getDoubles().read(2);

                double bps = MovementUtil.horizontalBps(s, x, z, now);
                if (bps <= 0.0) return;

                // Rough expected displacement based on expected velocity magnitude.
                // Compare ratio of observed bps to expected*20 (approx ticks), keep it lenient for SMP.
                double ratioMin = plugin.getConfig().getDouble("checks.velocity.min-horizontal-ratio", 0.35);

                // expectedVelXZ is blocks/tick-ish after scaling; convert to blocks/sec-ish
                double expectedBps = s.expectedVelXZ * 20.0;
                if (expectedBps <= 0.01) return;

                double ratio = bps / expectedBps;

                if (ratio < ratioMin) {
                    double add = plugin.getConfig().getDouble("checks.velocity.vl-per-flag", 1.2);
                    double vl = s.addVl(CheckType.VELOCITY, add);
                    alerts.alert("VelocityA", p, String.format("ratio=%.2f bps=%.2f exp=%.2f", ratio, bps, expectedBps), vl);

                    double banTh = plugin.getConfig().getDouble("checks.velocity.ban-threshold", 10.0);
                    Punish.maybeBan(plugin, p, "VelocityA", vl, banTh);

                    // clear expectation to avoid spam
                    s.lastVelocityMs = 0L;
                    s.expectedVelXZ = 0.0;
                }
            }
        };

        protocol.addPacketListener(sendAdapter);
        protocol.addPacketListener(moveAdapter);
    }

    @Override
    public void close() {
        protocol.removePacketListener(sendAdapter);
        protocol.removePacketListener(moveAdapter);
    }
}
