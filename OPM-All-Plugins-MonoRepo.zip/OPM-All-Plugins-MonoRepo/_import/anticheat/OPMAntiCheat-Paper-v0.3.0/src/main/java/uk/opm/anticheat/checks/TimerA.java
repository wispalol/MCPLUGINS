package uk.opm.anticheat.checks;

import com.comphenix.protocol.ProtocolManager;
import com.comphenix.protocol.PacketType;
import com.comphenix.protocol.events.PacketAdapter;
import com.comphenix.protocol.events.PacketEvent;
import org.bukkit.GameMode;
import org.bukkit.entity.Player;
import uk.opm.anticheat.CheckType;
import uk.opm.anticheat.OPMAntiCheatPlugin;
import uk.opm.anticheat.data.PlayerDataStore;
import uk.opm.anticheat.data.PlayerState;
import uk.opm.anticheat.util.AlertService;
import uk.opm.anticheat.util.Punish;

public final class TimerA implements AutoCloseable {
    private final OPMAntiCheatPlugin plugin;
    private final ProtocolManager protocol;
    private final PlayerDataStore data;
    private final AlertService alerts;
    private final PacketAdapter adapter;

    public TimerA(OPMAntiCheatPlugin plugin, ProtocolManager protocol, PlayerDataStore data, AlertService alerts) {
        this.plugin = plugin;
        this.protocol = protocol;
        this.data = data;
        this.alerts = alerts;

        adapter = new PacketAdapter(plugin,
                PacketType.Play.Client.FLYING,
                PacketType.Play.Client.POSITION,
                PacketType.Play.Client.POSITION_LOOK,
                PacketType.Play.Client.LOOK) {
            @Override
            public void onPacketReceiving(PacketEvent event) {
                if (!plugin.getConfig().getBoolean("checks.timer.enabled", true)) return;

                Player p = event.getPlayer();
                if (p == null || !p.isOnline()) return;
                if (p.hasPermission("opmac.bypass")) return;
                if (p.getGameMode() == GameMode.CREATIVE || p.getGameMode() == GameMode.SPECTATOR) return;

                PlayerState s = data.get(p);
                long now = System.currentTimeMillis();

                long window = 1000L;
                s.movePacketTimes.addLast(now);
                while (!s.movePacketTimes.isEmpty() && (now - s.movePacketTimes.peekFirst()) > window) {
                    s.movePacketTimes.removeFirst();
                }

                int pps = s.movePacketTimes.size();
                int max = plugin.getConfig().getInt("checks.timer.max-move-packets-per-second", 30);

                if (pps > max) {
                    double add = plugin.getConfig().getDouble("checks.timer.vl-per-flag", 1.0);
                    double vl = s.addVl(CheckType.TIMER, add);

                    alerts.alert("TimerA", p, "pps=" + pps + " max=" + max, vl);

                    double banTh = plugin.getConfig().getDouble("checks.timer.ban-threshold", 12.0);
                    Punish.maybeBan(plugin, p, "TimerA", vl, banTh);

                    s.movePacketTimes.clear();
                }
            }
        };

        protocol.addPacketListener(adapter);
    }

    @Override
    public void close() { protocol.removePacketListener(adapter); }
}
