package uk.opm.anticheat.data;

import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

public final class PlayerDataStore {
    private final JavaPlugin plugin;
    private final Map<UUID, PlayerState> map = new ConcurrentHashMap<>();

    public PlayerDataStore(JavaPlugin plugin) {
        this.plugin = plugin;
    }

    public PlayerState get(Player p) {
        return map.computeIfAbsent(p.getUniqueId(), k -> new PlayerState());
    }

    public void startDecayTask() {
        double decay = plugin.getConfig().getDouble("decay-per-second", 0.35);
        Bukkit.getScheduler().runTaskTimer(plugin, () -> {
            for (Player p : Bukkit.getOnlinePlayers()) {
                get(p).decayAll(decay);
            }
        }, 20L, 20L);
    }
}
