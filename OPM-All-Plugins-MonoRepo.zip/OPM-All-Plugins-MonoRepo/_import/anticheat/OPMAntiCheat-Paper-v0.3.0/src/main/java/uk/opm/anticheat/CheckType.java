package uk.opm.anticheat;

public enum CheckType {
    SPEED,
    FLY,
    TIMER,
    REACH,
    AUTOCLICKER,
    NOSLOW,
    FASTPLACE,
    VELOCITY
}
