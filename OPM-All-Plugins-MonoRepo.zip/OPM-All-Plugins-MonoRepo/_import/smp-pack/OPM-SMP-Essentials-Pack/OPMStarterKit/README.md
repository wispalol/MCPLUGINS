# OPMStarterKit

First-join kit + /kit.

Build: mvn clean package
