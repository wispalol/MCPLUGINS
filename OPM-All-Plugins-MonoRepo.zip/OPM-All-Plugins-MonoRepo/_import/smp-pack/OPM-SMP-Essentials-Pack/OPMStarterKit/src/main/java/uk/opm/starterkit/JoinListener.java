package uk.opm.starterkit;

import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;

public final class JoinListener implements Listener {
    private final OPMStarterKitPlugin plugin;
    public JoinListener(OPMStarterKitPlugin plugin) { this.plugin = plugin; }

    @EventHandler
    public void onJoin(PlayerJoinEvent e) {
        if (!plugin.getConfig().getBoolean("enabled", true)) return;
        if (!plugin.getConfig().getBoolean("give-on-first-join", true)) return;
        if (!e.getPlayer().hasPlayedBefore()) {
            KitUtil.giveKit(plugin, e.getPlayer(), true);
        }
    }
}
