package uk.opm.starterkit;

import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.File;
import java.io.IOException;
import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

public final class KitStore {
    private final JavaPlugin plugin;
    private final File file;
    private final Set<UUID> claimed = new HashSet<>();

    public KitStore(JavaPlugin plugin) {
        this.plugin = plugin;
        this.file = new File(plugin.getDataFolder(), "claimed.yml");
    }

    public boolean has(UUID u) { return claimed.contains(u); }
    public void mark(UUID u) { claimed.add(u); save(); }

    public void load() {
        if (!file.exists()) return;
        YamlConfiguration y = YamlConfiguration.loadConfiguration(file);
        for (String s : y.getStringList("claimed")) {
            try { claimed.add(UUID.fromString(s)); } catch (Exception ignored) {}
        }
    }

    public void save() {
        YamlConfiguration y = new YamlConfiguration();
        java.util.List<String> out = new java.util.ArrayList<>();
        for (UUID u : claimed) out.add(u.toString());
        y.set("claimed", out);
        try { plugin.getDataFolder().mkdirs(); y.save(file); } catch (IOException ignored) {}
    }
}
