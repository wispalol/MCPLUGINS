package uk.opm.starterkit;

import net.kyori.adventure.text.Component;
import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public final class KitCommand implements CommandExecutor {
    private final OPMStarterKitPlugin plugin;
    public KitCommand(OPMStarterKitPlugin plugin) { this.plugin = plugin; }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player p)) return true;
        if (!p.hasPermission("opmkit.use")) return true;
        boolean ok = KitUtil.giveKit(plugin, p, false);
        if (!ok) msg(p, plugin.getConfig().getString("messages.already","&cAlready claimed."));
        return true;
    }

    static void msg(Player p, String s) {
        if (s == null) return;
        p.sendMessage(Component.text(ChatColor.translateAlternateColorCodes('&', s)));
    }
}
