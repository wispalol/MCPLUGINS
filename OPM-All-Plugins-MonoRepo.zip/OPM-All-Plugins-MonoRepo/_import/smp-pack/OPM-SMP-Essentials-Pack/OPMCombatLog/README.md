# OPMCombatLog

Combat tag players and punish logout (kill or tempban).

Build: mvn clean package
