# OPMRTP

Random teleport with safe-location checks, warmup, cooldown.

Build: mvn clean package
