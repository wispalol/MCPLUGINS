package uk.opm.rtp;

import net.kyori.adventure.text.Component;
import org.bukkit.*;
import org.bukkit.block.Block;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ThreadLocalRandom;

public final class RTPCommand implements CommandExecutor {
    private final OPMRTPPlugin plugin;
    private final Map<UUID, Long> lastUseMs = new ConcurrentHashMap<>();

    public RTPCommand(OPMRTPPlugin plugin) { this.plugin = plugin; }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player p)) return true;
        if (!p.hasPermission("opmrtp.use")) return true;

        if (!plugin.getConfig().getBoolean("enabled", true)) return true;

        long now = System.currentTimeMillis();
        int cd = Math.max(0, plugin.getConfig().getInt("cooldown-seconds", 600));
        if (!p.hasPermission("opmrtp.bypasscooldown")) {
            long last = lastUseMs.getOrDefault(p.getUniqueId(), 0L);
            long left = (last + cd*1000L) - now;
            if (left > 0) {
                msg(p, plugin.getConfig().getString("messages.cooldown", "&cCooldown: {seconds}s")
                        .replace("{seconds}", String.valueOf(left/1000L)));
                return true;
            }
        }

        int warmup = Math.max(0, plugin.getConfig().getInt("warmup-seconds", 5));
        Location start = p.getLocation().clone();

        if (warmup > 0) msg(p, plugin.getConfig().getString("messages.warmup", "&eTeleporting in {seconds}s...").replace("{seconds}", String.valueOf(warmup)));

        Bukkit.getScheduler().runTaskLater(plugin, () -> {
            // moved check
            if (p.isOnline()) {
                Location cur = p.getLocation();
                if (cur.getWorld() != start.getWorld() || cur.distanceSquared(start) > 0.25) {
                    msg(p, "§cRTP cancelled (you moved).");
                    return;
                }
                Bukkit.getScheduler().runTaskAsynchronously(plugin, () -> {
                    Location found = findSafe(p.getWorld());
                    Bukkit.getScheduler().runTask(plugin, () -> {
                        if (found == null) {
                            msg(p, plugin.getConfig().getString("messages.failed", "&cNo safe spot."));
                            return;
                        }
                        p.teleportAsync(found).thenRun(() -> {
                            lastUseMs.put(p.getUniqueId(), System.currentTimeMillis());
                            msg(p, plugin.getConfig().getString("messages.teleported", "&aTeleported!"));
                        });
                    });
                });
            }
        }, warmup * 20L);

        return true;
    }

    private Location findSafe(World world) {
        String wname = world.getName().toLowerCase();
        int radius;
        Environment env = world.getEnvironment();
        if (env == World.Environment.NETHER) radius = plugin.getConfig().getInt("radius.nether", 2000);
        else if (env == World.Environment.THE_END) radius = plugin.getConfig().getInt("radius.the_end", 2000);
        else radius = plugin.getConfig().getInt("radius.overworld", 5000);

        int attempts = Math.max(1, plugin.getConfig().getInt("attempts", 20));
        ThreadLocalRandom r = ThreadLocalRandom.current();

        for (int i = 0; i < attempts; i++) {
            int x = r.nextInt(-radius, radius+1);
            int z = r.nextInt(-radius, radius+1);

            int y = world.getHighestBlockYAt(x, z);
            if (env == World.Environment.NETHER) y = Math.min(120, y);
            if (env == World.Environment.THE_END) y = Math.min(120, y);

            Location loc = new Location(world, x + 0.5, y + 1, z + 0.5);
            Block feet = world.getBlockAt(loc.getBlockX(), loc.getBlockY(), loc.getBlockZ());
            Block head = world.getBlockAt(loc.getBlockX(), loc.getBlockY()+1, loc.getBlockZ());
            Block below = world.getBlockAt(loc.getBlockX(), loc.getBlockY()-1, loc.getBlockZ());

            if (!below.getType().isSolid()) continue;
            if (below.getType() == Material.LAVA || below.getType() == Material.MAGMA_BLOCK) continue;
            if (feet.getType() != Material.AIR && !feet.isPassable()) continue;
            if (head.getType() != Material.AIR && !head.isPassable()) continue;

            // avoid liquid spawn
            if (below.isLiquid() || feet.isLiquid() || head.isLiquid()) continue;

            return loc;
        }
        return null;
    }

    private static void msg(Player p, String s) {
        if (s == null) return;
        p.sendMessage(Component.text(ChatColor.translateAlternateColorCodes('&', s)));
    }
}
