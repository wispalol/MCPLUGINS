# OPMBetterSleep

Skip night when X% of players are sleeping.

Build: mvn clean package
