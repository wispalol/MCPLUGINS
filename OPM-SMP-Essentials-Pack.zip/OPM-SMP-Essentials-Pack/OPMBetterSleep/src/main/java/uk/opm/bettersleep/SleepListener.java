package uk.opm.bettersleep;

import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.World;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerBedEnterEvent;
import org.bukkit.event.player.PlayerBedLeaveEvent;

public final class SleepListener implements Listener {
    private final OPMBetterSleepPlugin plugin;
    public SleepListener(OPMBetterSleepPlugin plugin) { this.plugin = plugin; }

    @EventHandler
    public void onBedEnter(PlayerBedEnterEvent e) {
        if (!plugin.getConfig().getBoolean("enabled", true)) return;
        if (e.getBedEnterResult() != PlayerBedEnterEvent.BedEnterResult.OK) return;
        tick(e.getPlayer().getWorld());
    }

    @EventHandler
    public void onBedLeave(PlayerBedLeaveEvent e) {
        if (!plugin.getConfig().getBoolean("enabled", true)) return;
        tick(e.getPlayer().getWorld());
    }

    private void tick(World w) {
        if (w.getEnvironment() != World.Environment.NORMAL) return;
        int online = 0, sleeping = 0;
        for (Player p : Bukkit.getOnlinePlayers()) {
            if (p.getWorld() != w) continue;
            online++;
            if (p.isSleeping()) sleeping++;
        }
        if (online <= 0) return;

        int pct = Math.max(1, Math.min(100, plugin.getConfig().getInt("required-percent", 50)));
        int required = (int)Math.ceil((pct / 100.0) * online);

        broadcast(plugin.getConfig().getString("messages.progress","&eSleepers: {sleeping}/{required}")
                .replace("{sleeping}", String.valueOf(sleeping))
                .replace("{required}", String.valueOf(required))
                .replace("{online}", String.valueOf(online)));

        if (sleeping >= required && w.getTime() > 12541) { // night-ish
            Bukkit.getScheduler().runTask(plugin, () -> {
                w.setTime(1000);
                w.setStorm(false);
                w.setThundering(false);
                broadcast(plugin.getConfig().getString("messages.skipped","&aNight skipped!"));
            });
        }
    }

    private void broadcast(String s) {
        if (s == null) return;
        Component c = Component.text(ChatColor.translateAlternateColorCodes('&', s));
        for (Player p : Bukkit.getOnlinePlayers()) p.sendMessage(c);
    }
}
