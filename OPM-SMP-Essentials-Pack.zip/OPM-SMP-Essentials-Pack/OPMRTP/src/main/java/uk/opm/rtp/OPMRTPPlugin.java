package uk.opm.rtp;

import org.bukkit.plugin.java.JavaPlugin;

public final class OPMRTPPlugin extends JavaPlugin {
    @Override
    public void onEnable() {
        saveDefaultConfig();
        if (getCommand("rtp") != null) getCommand("rtp").setExecutor(new RTPCommand(this));
    }
}
