package uk.opm.starterkit;

import net.kyori.adventure.text.Component;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

public final class KitUtil {
    private KitUtil() {}

    public static boolean giveKit(OPMStarterKitPlugin plugin, Player p, boolean firstJoin) {
        if (!plugin.getConfig().getBoolean("enabled", true)) return false;
        if (plugin.store().has(p.getUniqueId())) return false;

        for (String line : plugin.getConfig().getStringList("items")) {
            if (line == null || line.isBlank()) continue;
            String[] parts = line.trim().split("\\s+");
            try {
                Material m = Material.valueOf(parts[0].toUpperCase());
                int amt = parts.length > 1 ? Integer.parseInt(parts[1]) : 1;
                p.getInventory().addItem(new ItemStack(m, Math.max(1, amt)));
            } catch (Exception ignored) {}
        }

        plugin.store().mark(p.getUniqueId());
        String msg = plugin.getConfig().getString("messages.received","&aYou received your kit!");
        p.sendMessage(Component.text(ChatColor.translateAlternateColorCodes('&', msg)));
        return true;
    }
}
