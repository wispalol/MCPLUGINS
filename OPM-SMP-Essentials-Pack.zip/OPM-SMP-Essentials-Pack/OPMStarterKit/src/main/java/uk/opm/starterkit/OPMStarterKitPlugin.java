package uk.opm.starterkit;

import org.bukkit.plugin.java.JavaPlugin;

public final class OPMStarterKitPlugin extends JavaPlugin {
    private KitStore store;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        store = new KitStore(this);
        store.load();

        getServer().getPluginManager().registerEvents(new JoinListener(this), this);
        if (getCommand("kit") != null) getCommand("kit").setExecutor(new KitCommand(this));
    }

    @Override
    public void onDisable() {
        if (store != null) store.save();
    }

    public KitStore store() { return store; }
}
