package uk.opm.announce;

import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.List;
import java.util.concurrent.ThreadLocalRandom;

public final class OPMAnnouncementsPlugin extends JavaPlugin implements Listener {
    @Override
    public void onEnable() {
        saveDefaultConfig();
        if (!getConfig().getBoolean("enabled", true)) return;

        getServer().getPluginManager().registerEvents(this, this);

        if (getConfig().getBoolean("broadcast.enabled", true)) {
            long interval = Math.max(10, getConfig().getLong("broadcast.interval-seconds", 600));
            Bukkit.getScheduler().runTaskTimer(this, this::broadcastRandom, interval * 20L, interval * 20L);
        }
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent e) {
        String m = getConfig().getString("join-message", "&a+ {player}").replace("{player}", e.getPlayer().getName());
        e.joinMessage(Component.text(color(m)));
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        String m = getConfig().getString("quit-message", "&c- {player}").replace("{player}", e.getPlayer().getName());
        e.quitMessage(Component.text(color(m)));
    }

    private void broadcastRandom() {
        List<String> msgs = getConfig().getStringList("broadcast.messages");
        if (msgs == null || msgs.isEmpty()) return;
        String pick = msgs.get(ThreadLocalRandom.current().nextInt(msgs.size()));
        Component c = Component.text(color(pick));
        for (Player p : Bukkit.getOnlinePlayers()) p.sendMessage(c);
        Bukkit.getConsoleSender().sendMessage(color(pick));
    }

    private static String color(String s) { return ChatColor.translateAlternateColorCodes('&', s == null ? "" : s); }
}
