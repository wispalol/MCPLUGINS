package uk.opm.combatlog;

import net.kyori.adventure.text.Component;
import org.bukkit.BanList;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.OfflinePlayer;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.player.PlayerQuitEvent;

import java.time.Duration;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

public final class CombatTag implements Listener, CommandExecutor {
    private final OPMCombatLogPlugin plugin;
    private final Map<UUID, Long> taggedUntilMs = new ConcurrentHashMap<>();

    public CombatTag(OPMCombatLogPlugin plugin) { this.plugin = plugin; }

    @EventHandler
    public void onHit(EntityDamageByEntityEvent e) {
        if (!plugin.getConfig().getBoolean("enabled", true)) return;
        if (!(e.getEntity() instanceof Player victim)) return;

        Player attacker = null;
        if (e.getDamager() instanceof Player p) attacker = p;
        else if (e.getDamager() instanceof org.bukkit.entity.Projectile proj && proj.getShooter() instanceof Player p) attacker = p;
        if (attacker == null) return;

        if (victim.hasPermission("opmcombat.bypass") || attacker.hasPermission("opmcombat.bypass")) return;

        int tagSec = Math.max(1, plugin.getConfig().getInt("tag-seconds", 15));
        long until = System.currentTimeMillis() + tagSec * 1000L;

        taggedUntilMs.put(victim.getUniqueId(), until);
        taggedUntilMs.put(attacker.getUniqueId(), until);

        msg(victim, plugin.getConfig().getString("messages.tagged", "&cIn combat {seconds}s").replace("{seconds}", String.valueOf(tagSec)));
        msg(attacker, plugin.getConfig().getString("messages.tagged", "&cIn combat {seconds}s").replace("{seconds}", String.valueOf(tagSec)));
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        if (!plugin.getConfig().getBoolean("enabled", true)) return;
        Player p = e.getPlayer();
        if (p.hasPermission("opmcombat.bypass")) return;

        long left = remainingSeconds(p.getUniqueId());
        if (left <= 0) return;

        if (!plugin.getConfig().getBoolean("punish-on-logout", true)) return;

        String type = plugin.getConfig().getString("punish.type", "KILL").toUpperCase();
        switch (type) {
            case "BAN" -> {
                long banSec = Math.max(60, plugin.getConfig().getLong("punish.ban-seconds", 3600));
                var exp = java.util.Date.from(java.time.Instant.now().plusSeconds(banSec));
                Bukkit.getBanList(BanList.Type.NAME).addBan(p.getName(), "Combat logging", exp, null);
            }
            case "KILL" -> {
                // make sure drop inventory / death happens
                Bukkit.getScheduler().runTask(plugin, () -> {
                    if (p.isOnline()) return;
                    // can't kill offline; best effort: set health before quit doesn't apply.
                    // Alternative: store and punish on next join. We'll do that.
                    plugin.getServer().getPersistentDataContainer(); // no-op
                });
                CombatLogPunishStore.mark(plugin, p.getUniqueId());
            }
            default -> CombatLogPunishStore.mark(plugin, p.getUniqueId());
        }
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player p)) return true;
        long left = remainingSeconds(p.getUniqueId());
        msg(p, plugin.getConfig().getString("messages.status", "&eRemaining: {seconds}s").replace("{seconds}", String.valueOf(left)));
        return true;
    }

    long remainingSeconds(UUID u) {
        long until = taggedUntilMs.getOrDefault(u, 0L);
        long leftMs = until - System.currentTimeMillis();
        return Math.max(0, leftMs / 1000L);
    }

    static void msg(Player p, String s) {
        if (s == null) return;
        p.sendMessage(Component.text(ChatColor.translateAlternateColorCodes('&', s)));
    }
}
