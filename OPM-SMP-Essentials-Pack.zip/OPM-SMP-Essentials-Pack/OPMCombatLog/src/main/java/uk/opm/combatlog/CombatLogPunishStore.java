package uk.opm.combatlog;

import org.bukkit.Bukkit;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.File;
import java.io.IOException;
import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

public final class CombatLogPunishStore implements Listener {
    private final JavaPlugin plugin;
    private final File file;
    private final Set<UUID> pending = new HashSet<>();

    public CombatLogPunishStore(JavaPlugin plugin) {
        this.plugin = plugin;
        this.file = new File(plugin.getDataFolder(), "punish.yml");
        load();
    }

    public static void mark(JavaPlugin plugin, UUID u) {
        CombatLogPunishStore store = new CombatLogPunishStore(plugin);
        store.pending.add(u);
        store.save();
        Bukkit.getPluginManager().registerEvents(store, plugin);
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent e) {
        Player p = e.getPlayer();
        if (!pending.remove(p.getUniqueId())) return;
        save();
        // punish = kill on join (simple and effective)
        Bukkit.getScheduler().runTask(plugin, () -> {
            if (p.isDead()) return;
            p.setHealth(0.0);
        });
    }

    private void load() {
        if (!file.exists()) return;
        YamlConfiguration y = YamlConfiguration.loadConfiguration(file);
        for (String s : y.getStringList("pending")) {
            try { pending.add(UUID.fromString(s)); } catch (Exception ignored) {}
        }
    }

    private void save() {
        YamlConfiguration y = new YamlConfiguration();
        java.util.List<String> out = new java.util.ArrayList<>();
        for (UUID u : pending) out.add(u.toString());
        y.set("pending", out);
        try {
            plugin.getDataFolder().mkdirs();
            y.save(file);
        } catch (IOException ignored) {}
    }
}
