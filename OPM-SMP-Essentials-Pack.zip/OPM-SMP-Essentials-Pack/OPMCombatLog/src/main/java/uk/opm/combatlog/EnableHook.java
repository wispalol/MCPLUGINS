package uk.opm.combatlog;

import org.bukkit.event.Listener;

public final class EnableHook implements Listener {
    // placeholder, kept for future expansion
}
