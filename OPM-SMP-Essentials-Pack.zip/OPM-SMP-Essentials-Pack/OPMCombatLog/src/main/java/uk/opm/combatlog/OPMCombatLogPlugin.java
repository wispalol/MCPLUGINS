package uk.opm.combatlog;

import org.bukkit.plugin.java.JavaPlugin;

public final class OPMCombatLogPlugin extends JavaPlugin {
    private CombatTag tag;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        tag = new CombatTag(this);
        getServer().getPluginManager().registerEvents(tag, this);
        if (getCommand("combattag") != null) getCommand("combattag").setExecutor(tag);
    }
}
