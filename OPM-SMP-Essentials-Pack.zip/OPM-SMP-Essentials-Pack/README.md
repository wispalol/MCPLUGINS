# OPM SMP Essentials Pack (Paper 1.21.11)

Useful SMP-focused plugins, each as its own GitHub-ready Maven project (Java 21).

## Included
- OPMRTP (random teleport with safety checks + cooldown)
- OPMCombatLog (combat tag + punish logout)
- OPMBetterSleep (percentage sleep)
- OPMStarterKit (first-join kit + /kit)
- OPMAnnouncements (join/quit messages + auto broadcasts)

Build any plugin:
```bash
mvn clean package
```
